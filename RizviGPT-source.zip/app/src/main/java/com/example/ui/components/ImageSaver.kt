package com.example.ui.components

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream

/** Saves a generated picture to the phone gallery (Pictures/Rizvi@gpt). Returns true on success. */
fun saveBitmapToGallery(context: Context, bitmap: Bitmap): Boolean {
  val fileName = "rizvigpt_${System.currentTimeMillis()}.jpg"
  return try {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/RizviGPT")
      }
      val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        ?: return false
      context.contentResolver.openOutputStream(uri)?.use { out ->
        bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
      } ?: return false
      true
    } else {
      // Older phones: app-specific pictures folder (no storage permission needed).
      val dir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: return false
      val file = File(dir, fileName)
      FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out) }
      true
    }
  } catch (_: Exception) {
    false
  }
}
