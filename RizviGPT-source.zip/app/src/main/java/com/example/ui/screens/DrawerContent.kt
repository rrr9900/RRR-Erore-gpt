package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ChatEntity
import com.example.viewmodel.KoraViewModel
import java.util.Calendar

@Composable
fun DrawerContent(
  viewModel: KoraViewModel,
  onOpenSettings: () -> Unit,
  onCloseDrawer: () -> Unit
) {
  val chats by viewModel.chats.collectAsState()
  val activeChatId by viewModel.activeChatId.collectAsState()
  val settings by viewModel.settings.collectAsState()

  var searchQuery by remember { mutableStateOf("") }

  val filteredChats = remember(chats, searchQuery) {
    if (searchQuery.isBlank()) chats
    else chats.filter { it.title.contains(searchQuery, ignoreCase = true) }
  }

  // Group chats by date
  val groupedChats = remember(filteredChats) {
    groupChatsByDate(filteredChats)
  }

  Column(
    modifier = Modifier
      .fillMaxWidth(0.85f)
      .fillMaxHeight()
      .background(MaterialTheme.colorScheme.surface)
      .statusBarsPadding()
      .navigationBarsPadding()
      .padding(horizontal = 16.dp, vertical = 12.dp)
  ) {
    // New Chat Button
    Button(
      onClick = {
        viewModel.createNewChat()
        onCloseDrawer()
      },
      shape = RoundedCornerShape(24.dp),
      colors = ButtonDefaults.buttonColors(
        containerColor = MaterialTheme.colorScheme.primaryContainer,
        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
      ),
      modifier = Modifier
        .fillMaxWidth()
        .height(48.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Add,
          contentDescription = null,
          modifier = Modifier.size(20.dp)
        )
        Text(
          text = "New chat",
          style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Search field
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      placeholder = { Text("Search chats...", fontSize = 14.sp) },
      leadingIcon = {
        Icon(
          imageVector = Icons.Default.Search,
          contentDescription = "Search",
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.size(18.dp)
        )
      },
      singleLine = true,
      shape = RoundedCornerShape(16.dp),
      colors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = MaterialTheme.colorScheme.primary,
        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
      ),
      modifier = Modifier
        .fillMaxWidth()
        .height(50.dp)
    )

    Spacer(modifier = Modifier.height(14.dp))

    // Chat History List
    LazyColumn(
      modifier = Modifier.weight(1f),
      verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
      groupedChats.forEach { (category, chatList) ->
        item {
          Text(
            text = category,
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            modifier = Modifier.padding(top = 10.dp, bottom = 4.dp, start = 8.dp)
          )
        }

        items(chatList, key = { it.id }) { chat ->
          val isSelected = chat.id == activeChatId
          ChatHistoryRow(
            chat = chat,
            isSelected = isSelected,
            onSelect = {
              viewModel.selectChat(chat.id)
              onCloseDrawer()
            },
            onDelete = { viewModel.deleteChat(chat.id) },
            onTogglePin = { viewModel.togglePinChat(chat.id) }
          )
        }
      }
    }

    HorizontalDivider(
      color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
      modifier = Modifier.padding(vertical = 10.dp)
    )

    // User Profile row at bottom
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .clickable {
          onOpenSettings()
          onCloseDrawer()
        }
    ) {
      Row(
        modifier = Modifier.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = settings.userName.take(1).uppercase(),
            style = MaterialTheme.typography.titleMedium.copy(
              color = Color.White,
              fontWeight = FontWeight.Bold
            )
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = settings.userName,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Text(
            text = "Settings & Voice",
            style = MaterialTheme.typography.bodySmall.copy(
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          )
        }
        Icon(
          imageVector = Icons.Default.Settings,
          contentDescription = "Settings",
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.size(20.dp)
        )
      }
    }
  }
}

@Composable
private fun ChatHistoryRow(
  chat: ChatEntity,
  isSelected: Boolean,
  onSelect: () -> Unit,
  onDelete: () -> Unit,
  onTogglePin: () -> Unit
) {
  var menuExpanded by remember { mutableStateOf(false) }

  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .clickable(onClick = onSelect),
    color = if (isSelected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent,
    shape = RoundedCornerShape(14.dp)
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = if (chat.isPinned) Icons.Filled.PushPin else Icons.Default.ChatBubbleOutline,
        contentDescription = null,
        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(18.dp)
      )
      Spacer(modifier = Modifier.width(10.dp))
      Text(
        text = chat.title,
        style = MaterialTheme.typography.bodyMedium.copy(
          fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
          color = MaterialTheme.colorScheme.onSurface
        ),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.weight(1f)
      )

      Box {
        IconButton(
          onClick = { menuExpanded = true },
          modifier = Modifier.size(28.dp)
        ) {
          Icon(
            imageVector = Icons.Default.MoreVert,
            contentDescription = "Options",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(16.dp)
          )
        }

        DropdownMenu(
          expanded = menuExpanded,
          onDismissRequest = { menuExpanded = false }
        ) {
          DropdownMenuItem(
            text = { Text(if (chat.isPinned) "Unpin" else "Pin") },
            leadingIcon = {
              Icon(
                imageVector = if (chat.isPinned) Icons.Outlined.PushPin else Icons.Filled.PushPin,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
              )
            },
            onClick = {
              onTogglePin()
              menuExpanded = false
            }
          )
          DropdownMenuItem(
            text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
            leadingIcon = {
              Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(16.dp)
              )
            },
            onClick = {
              onDelete()
              menuExpanded = false
            }
          )
        }
      }
    }
  }
}

private fun groupChatsByDate(chats: List<ChatEntity>): Map<String, List<ChatEntity>> {
  val now = Calendar.getInstance()
  val todayStart = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
  }.timeInMillis

  val yesterdayStart = todayStart - (24 * 60 * 60 * 1000)
  val sevenDaysAgo = todayStart - (7 * 24 * 60 * 60 * 1000)

  val groups = linkedMapOf<String, MutableList<ChatEntity>>()

  chats.forEach { chat ->
    val key = when {
      chat.isPinned -> "Pinned"
      chat.updatedAt >= todayStart -> "Today"
      chat.updatedAt >= yesterdayStart -> "Yesterday"
      chat.updatedAt >= sevenDaysAgo -> "Previous 7 Days"
      else -> "Older"
    }
    groups.getOrPut(key) { mutableListOf() }.add(chat)
  }

  return groups
}
