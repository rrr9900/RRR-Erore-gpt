package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.data.remote.IMAGE_ASPECTS
import com.example.data.remote.IMAGE_STYLES
import com.example.ui.components.NatureBackground
import com.example.ui.components.AttachmentBottomSheet
import com.example.ui.components.KoraOrb
import com.example.ui.components.MessageItem
import com.example.ui.components.SuggestionChipsRow
import com.example.viewmodel.KoraViewModel
import com.example.voice.OrbVisualState
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
  viewModel: KoraViewModel,
  onOpenDrawer: () -> Unit,
  onOpenVoiceMode: () -> Unit
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val listState = rememberLazyListState()

  val settings by viewModel.settings.collectAsState()
  val chats by viewModel.chats.collectAsState()
  val activeChatId by viewModel.activeChatId.collectAsState()
  val messages by viewModel.messages.collectAsState()
  val inputText by viewModel.inputText.collectAsState()
  val attachedImages by viewModel.attachedImages.collectAsState()
  val isImageGenMode by viewModel.isImageGenMode.collectAsState()
  val isGenerating by viewModel.isGenerating.collectAsState()
  val isSpeaking by viewModel.voiceManager.isSpeaking.collectAsState()
  val imageStyleId by viewModel.imageStyleId.collectAsState()
  val imageAspectId by viewModel.imageAspectId.collectAsState()

  // Microphone permission is asked only when the user really taps a mic button.
  var pendingMicAction by remember { mutableStateOf<(() -> Unit)?>(null) }
  val micPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { granted ->
    if (granted) {
      pendingMicAction?.invoke()
    } else {
      Toast.makeText(context, "Microphone permission is needed for voice.", Toast.LENGTH_SHORT).show()
    }
    pendingMicAction = null
  }
  fun withMicPermission(action: () -> Unit) {
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
      PackageManager.PERMISSION_GRANTED
    ) {
      action()
    } else {
      pendingMicAction = action
      micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
  }

  val currentChat = remember(chats, activeChatId) {
    chats.find { it.id == activeChatId }
  }

  var showMenu by remember { mutableStateOf(false) }
  var showRenameDialog by remember { mutableStateOf(false) }
  var renameText by remember { mutableStateOf("") }
  var showAttachmentSheet by remember { mutableStateOf(false) }
  var fullscreenImagePath by remember { mutableStateOf<String?>(null) }

  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  // Gallery Picker launcher
  val galleryLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetMultipleContents()
  ) { uris: List<Uri> ->
    uris.take(4).forEach { uri ->
      try {
        val inputStream = context.contentResolver.openInputStream(uri)
        val file = File(context.cacheDir, "kora_img_${System.currentTimeMillis()}_${(100..999).random()}.jpg")
        val outputStream = FileOutputStream(file)
        inputStream?.copyTo(outputStream)
        inputStream?.close()
        outputStream.close()
        viewModel.addAttachedImage(file.absolutePath)
      } catch (_: Exception) {}
    }
  }

  // Camera capture launcher
  var tempCameraFile by remember { mutableStateOf<File?>(null) }
  val cameraLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.TakePicturePreview()
  ) { bitmap ->
    if (bitmap != null) {
      try {
        val file = File(context.cacheDir, "kora_cam_${System.currentTimeMillis()}.jpg")
        val outputStream = FileOutputStream(file)
        bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, outputStream)
        outputStream.close()
        viewModel.addAttachedImage(file.absolutePath)
      } catch (_: Exception) {}
    }
  }

  // Scroll to bottom when new messages arrive
  LaunchedEffect(messages.size, messages.lastOrNull()?.content?.length) {
    if (messages.isNotEmpty()) {
      listState.animateScrollToItem(messages.size - 1)
    }
  }

  val showScrollToBottom by remember {
    derivedStateOf {
      val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
      messages.isNotEmpty() && lastVisible < messages.size - 2
    }
  }

  Box(modifier = Modifier.fillMaxSize()) {
    // Soft animated nature scene behind everything
    NatureBackground(modifier = Modifier.fillMaxSize())

  Box(
    modifier = Modifier
      .fillMaxSize()
      .statusBarsPadding()
      .navigationBarsPadding()
      .imePadding()
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
      // 1. Top App Bar
      Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.Transparent,
        tonalElevation = 0.dp
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = onOpenDrawer) {
            Icon(
              imageVector = Icons.Default.Menu,
              contentDescription = "Open history drawer",
              tint = MaterialTheme.colorScheme.onSurface
            )
          }

          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.weight(1f)
          ) {
            Text(
              text = currentChat?.title ?: "Rizvi@gpt",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
              ),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            if (isImageGenMode) {
              Text(
                text = "Image Mode • " +
                  (IMAGE_STYLES.firstOrNull { it.id == imageStyleId }?.label ?: "") +
                  " • " + imageAspectId,
                style = MaterialTheme.typography.labelSmall.copy(
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.primary,
                  fontWeight = FontWeight.SemiBold
                )
              )
            }
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { viewModel.createNewChat() }) {
              Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "New chat",
                tint = MaterialTheme.colorScheme.onSurface
              )
            }

            Box {
              IconButton(onClick = { showMenu = true }) {
                Icon(
                  imageVector = Icons.Default.MoreVert,
                  contentDescription = "Menu options",
                  tint = MaterialTheme.colorScheme.onSurface
                )
              }

              DropdownMenu(
                expanded = showMenu,
                onDismissRequest = { showMenu = false }
              ) {
                if (currentChat != null) {
                  DropdownMenuItem(
                    text = { Text("Rename chat") },
                    onClick = {
                      renameText = currentChat.title
                      showRenameDialog = true
                      showMenu = false
                    }
                  )
                  DropdownMenuItem(
                    text = { Text("Export as text") },
                    onClick = {
                      val textContent = messages.joinToString("\n\n") {
                        "${it.role.uppercase()}: ${it.content}"
                      }
                      val sendIntent = Intent().apply {
                        action = Intent.ACTION_SEND
                        putExtra(Intent.EXTRA_TEXT, textContent)
                        type = "text/plain"
                      }
                      context.startActivity(Intent.createChooser(sendIntent, "Export Chat Text"))
                      showMenu = false
                    }
                  )
                  DropdownMenuItem(
                    text = { Text("Delete chat", color = MaterialTheme.colorScheme.error) },
                    onClick = {
                      viewModel.deleteChat(currentChat.id)
                      showMenu = false
                    }
                  )
                }
                DropdownMenuItem(
                  text = { Text("Clear all chats", color = MaterialTheme.colorScheme.error) },
                  onClick = {
                    viewModel.clearAllChats()
                    showMenu = false
                  }
                )
              }
            }
          }
        }
      }

      // 2. Chat Feed or Empty State
      Box(modifier = Modifier.weight(1f)) {
        if (messages.isEmpty()) {
          // Empty State
          Column(
            modifier = Modifier
              .fillMaxSize()
              .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
          ) {
            KoraOrb(
              state = OrbVisualState.IDLE,
              orbSize = 130.dp
            )
            Spacer(modifier = Modifier.height(20.dp))
            Text(
              text = if (settings.userName.isBlank()) "Hi there," else "Hi ${settings.userName},",
              style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp
              ),
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "What shall we create today?",
              style = MaterialTheme.typography.bodyLarge.copy(
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Horizontally scrollable suggestion chips
            SuggestionChipsRow(
              onSuggestionClick = { item ->
                viewModel.setInputText(item.prompt)
                if (item.needsImage) {
                  galleryLauncher.launch("image/*")
                }
              }
            )
          }
        } else {
          // Message List
          LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            items(messages, key = { it.id }) { msg ->
              MessageItem(
                message = msg,
                isSpeaking = isSpeaking,
                onSpeak = { text ->
                  if (isSpeaking) {
                    viewModel.voiceManager.stopSpeaking()
                  } else {
                    viewModel.voiceManager.speak(text, settings.voicePersona, settings.speechRate)
                  }
                },
                onRegenerate = { viewModel.regenerateResponse(msg.id) },
                onFeedback = { feedback -> viewModel.updateFeedback(msg.id, feedback) },
                onImageClick = { path -> fullscreenImagePath = path }
              )
            }
          }
        }

        // Floating Scroll-To-Bottom button
        if (showScrollToBottom) {
          FloatingActionButton(
            onClick = {
              coroutineScope.launch {
                if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
              }
            },
            shape = CircleShape,
            modifier = Modifier
              .align(Alignment.BottomEnd)
              .padding(16.dp)
              .size(42.dp),
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
            elevation = FloatingActionButtonDefaults.elevation(4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.ArrowDownward,
              contentDescription = "Scroll to bottom",
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }

      // Stop generating bar if active
      AnimatedVisibility(visible = isGenerating) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 6.dp),
          horizontalArrangement = Arrangement.Center
        ) {
          Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
              .clip(RoundedCornerShape(20.dp))
              .clickable { viewModel.stopGenerating() }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Stop,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(16.dp)
              )
              Text(
                text = "Stop generating",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
              )
            }
          }
        }
      }

      // 3. Bottom Pill Input Bar
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 8.dp)
      ) {
        // Attached image preview chips above the input field
        if (attachedImages.isNotEmpty()) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            attachedImages.forEach { path ->
              Box(modifier = Modifier.size(60.dp)) {
                AsyncImage(
                  model = File(path),
                  contentDescription = null,
                  modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(12.dp)),
                  contentScale = ContentScale.Crop
                )
                IconButton(
                  onClick = { viewModel.removeAttachedImage(path) },
                  modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(20.dp)
                    .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                ) {
                  Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Remove image",
                    tint = Color.White,
                    modifier = Modifier.size(12.dp)
                  )
                }
              }
            }
          }
        }

        // Floating Input Pill
        Surface(
          shape = RoundedCornerShape(28.dp),
          color = MaterialTheme.colorScheme.surface.copy(alpha = 0.82f),
          shadowElevation = 4.dp,
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            // Plus / Attachment button
            IconButton(
              onClick = { showAttachmentSheet = true },
              modifier = Modifier.size(42.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Attachments",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            // Text Input
            TextField(
              value = inputText,
              onValueChange = { viewModel.setInputText(it) },
              placeholder = {
                Text(
                  text = if (isImageGenMode) "Describe image to generate..." else "Ask Rizvi@gpt anything",
                  style = MaterialTheme.typography.bodyMedium.copy(fontSize = 15.sp),
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              },
              colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                disabledContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent
              ),
              maxLines = 5,
              modifier = Modifier.weight(1f)
            )

            // Dictation Mic Button (speech to text)
            IconButton(
              onClick = {
                withMicPermission {
                  viewModel.startDictation()
                  Toast.makeText(context, "Listening...", Toast.LENGTH_SHORT).show()
                }
              },
              modifier = Modifier.size(38.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = "Dictate",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
              )
            }

            Spacer(modifier = Modifier.width(2.dp))

            // Primary Circular Action: Voice mode or Send
            val hasContent = inputText.trim().isNotEmpty() || attachedImages.isNotEmpty()
            IconButton(
              onClick = {
                if (hasContent) {
                  viewModel.sendMessage()
                } else {
                  withMicPermission {
                    viewModel.openVoiceMode()
                    onOpenVoiceMode()
                  }
                }
              },
              modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
            ) {
              Icon(
                imageVector = if (hasContent) Icons.AutoMirrored.Filled.ArrowForward else Icons.Default.GraphicEq,
                contentDescription = if (hasContent) "Send" else "Voice mode",
                tint = Color.White,
                modifier = Modifier.size(22.dp)
              )
            }
          }
        }
      }
    }
  }
  }

  // Bottom Sheet for Attachments
  if (showAttachmentSheet) {
    AttachmentBottomSheet(
      sheetState = sheetState,
      isImageGenMode = isImageGenMode,
      onImageGenToggle = { viewModel.setImageGenMode(it) },
      selectedStyleId = imageStyleId,
      onImageStyleChange = { viewModel.setImageStyle(it) },
      selectedAspectId = imageAspectId,
      onImageAspectChange = { viewModel.setImageAspect(it) },
      onCameraClick = { cameraLauncher.launch(null) },
      onGalleryClick = { galleryLauncher.launch("image/*") },
      onStyleSelected = { prompt ->
        val newText = if (inputText.isNotBlank()) "$inputText - $prompt" else prompt
        viewModel.setInputText(newText)
      },
      onDismiss = { showAttachmentSheet = false }
    )
  }

  // Rename Dialog
  if (showRenameDialog && currentChat != null) {
    AlertDialog(
      onDismissRequest = { showRenameDialog = false },
      title = { Text("Rename Chat") },
      text = {
        OutlinedTextField(
          value = renameText,
          onValueChange = { renameText = it },
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )
      },
      confirmButton = {
        TextButton(
          onClick = {
            if (renameText.isNotBlank()) {
              viewModel.renameChat(currentChat.id, renameText.trim())
            }
            showRenameDialog = false
          }
        ) {
          Text("Save")
        }
      },
      dismissButton = {
        TextButton(onClick = { showRenameDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }

  // Fullscreen Image Viewer Modal
  if (fullscreenImagePath != null) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(Color.Black.copy(alpha = 0.95f))
        .clickable { fullscreenImagePath = null },
      contentAlignment = Alignment.Center
    ) {
      AsyncImage(
        model = File(fullscreenImagePath!!),
        contentDescription = "Fullscreen view",
        modifier = Modifier.fillMaxWidth(0.95f),
        contentScale = ContentScale.Fit
      )
      IconButton(
        onClick = { fullscreenImagePath = null },
        modifier = Modifier
          .align(Alignment.TopEnd)
          .statusBarsPadding()
          .padding(16.dp)
          .background(Color.White.copy(alpha = 0.2f), CircleShape)
      ) {
        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
      }
    }
  }
}
