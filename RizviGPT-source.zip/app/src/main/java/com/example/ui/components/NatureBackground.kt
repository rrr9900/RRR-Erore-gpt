package com.example.ui.components

import android.provider.Settings
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

private data class NatureParticle(
  val x: Float,
  val y: Float,
  val rise: Int,
  val swayK: Int,
  val phase: Float,
  val size: Float,
  val twinkleK: Int
)

private val TWO_PI = (2.0 * PI).toFloat()

/**
 * Soft, slow, realistic-feeling nature scene that sits behind the whole chat:
 *  - sky gradient that follows the time of day (and the light / dark theme)
 *  - drifting mist, a sun or moon glow
 *  - layered hills that sway very gently
 *  - floating pollen / petals in the day, glowing fireflies at night
 *
 * Everything loops seamlessly every 60 seconds and is drawn on one Canvas, so it is cheap.
 * If the phone's animations are turned off the scene is drawn still.
 */
@Composable
fun NatureBackground(
  modifier: Modifier = Modifier,
  animated: Boolean = true
) {
  val context = LocalContext.current
  val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f

  val reduceMotion = remember {
    try {
      Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    } catch (_: Exception) {
      false
    }
  }
  val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
  val particles = remember {
    val random = Random(7)
    List(28) {
      NatureParticle(
        x = random.nextFloat(),
        y = random.nextFloat(),
        rise = 1 + random.nextInt(3),
        swayK = 1 + random.nextInt(2),
        phase = random.nextFloat(),
        size = 1.5f + random.nextFloat() * 3f,
        twinkleK = 1 + random.nextInt(3)
      )
    }
  }

  val transition = rememberInfiniteTransition(label = "natureTransition")
  val animatedT by transition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 60000, easing = LinearEasing)
    ),
    label = "natureT"
  )
  val running = animated && !reduceMotion

  Canvas(modifier = modifier.fillMaxSize()) {
    val t = if (running) animatedT else 0f
    val w = size.width
    val h = size.height

    // 1. Sky gradient
    val (skyTop, skyBottom) = skyColors(isDark, hour)
    drawRect(brush = Brush.verticalGradient(listOf(skyTop, skyBottom)))

    // 2. Sun / moon glow
    val sunProgress = ((hour - 6) / 12f).coerceIn(0.1f, 0.9f)
    if (isDark) {
      drawGlow(Offset(w * 0.82f, h * 0.10f), w * 0.42f, Color(0xFFBFE8FF).copy(alpha = 0.12f))
    } else {
      drawGlow(Offset(w * sunProgress, h * 0.08f), w * 0.55f, Color(0xFFFFE9B8).copy(alpha = 0.55f))
    }

    // 3. Drifting mist
    val mistColor = if (isDark) Color(0xFF9FD8C0).copy(alpha = 0.07f) else Color.White.copy(alpha = 0.40f)
    for (i in 0 until 3) {
      val cx = w * (0.2f + 0.3f * i + 0.12f * sin(TWO_PI * (t + i / 3f)))
      val cy = h * (0.30f + 0.18f * i) + h * 0.02f * sin(TWO_PI * (2f * t + i))
      drawGlow(Offset(cx, cy), w * 0.75f, mistColor)
    }

    // 4. Floating particles
    particles.forEach { p ->
      val px = (p.x + 0.03f * sin(TWO_PI * (p.swayK * t + p.phase))) * w
      val py = (1f - ((p.y + t * p.rise) % 1f)) * h
      val twinkle = 0.5f + 0.5f * sin(TWO_PI * (p.twinkleK * 6f * t + p.phase))
      val center = Offset(px, py)
      if (isDark) {
        val glowRadius = p.size * 5f
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(Color(0xFFD9F99D).copy(alpha = 0.55f * twinkle), Color.Transparent),
            center = center,
            radius = glowRadius
          ),
          radius = glowRadius,
          center = center
        )
        drawCircle(color = Color(0xFFF7FEC8).copy(alpha = 0.85f * twinkle), radius = p.size * 0.6f, center = center)
      } else {
        val petal = if (p.rise == 3) Color(0xFFFFC9D8) else Color.White
        drawCircle(color = petal.copy(alpha = 0.35f + 0.35f * twinkle), radius = p.size * 1.6f, center = center)
      }
    }

    // 5. Hills (back to front)
    val hills = if (isDark) {
      listOf(Color(0xFF123226), Color(0xFF0E281E), Color(0xFF0A1F17))
    } else {
      listOf(Color(0xFFCFE8D6), Color(0xFFBBDEC6), Color(0xFFA8D2B6))
    }
    drawHill(0.80f, 0.030f, 1.3f, 0.10f + 1.0f * t, hills[0].copy(alpha = if (isDark) 0.95f else 0.60f))
    drawHill(0.87f, 0.028f, 1.7f, 0.45f - 1.0f * t, hills[1].copy(alpha = if (isDark) 0.95f else 0.70f))
    drawHill(0.94f, 0.022f, 2.1f, 0.80f + 1.0f * t, hills[2].copy(alpha = if (isDark) 1f else 0.80f))
  }
}

private fun skyColors(isDark: Boolean, hour: Int): Pair<Color, Color> {
  return if (isDark) {
    when (hour) {
      in 5..8 -> Color(0xFF0C1E2B) to Color(0xFF0E261E)   // dawn
      in 9..16 -> Color(0xFF0A1B24) to Color(0xFF0C241B)  // day (dark theme)
      in 17..19 -> Color(0xFF14192B) to Color(0xFF0E2219) // dusk
      else -> Color(0xFF070F1A) to Color(0xFF0A1C15)      // night
    }
  } else {
    when (hour) {
      in 5..9 -> Color(0xFFFFF0DE) to Color(0xFFE7F5EA)   // morning
      in 10..15 -> Color(0xFFE2F2FB) to Color(0xFFEAF7EE) // day
      in 16..18 -> Color(0xFFFCE5DC) to Color(0xFFEAF0F6) // evening
      else -> Color(0xFFE3E9F5) to Color(0xFFE9F3EE)      // night
    }
  }
}

private fun DrawScope.drawGlow(center: Offset, radius: Float, color: Color) {
  drawCircle(
    brush = Brush.radialGradient(
      colors = listOf(color, Color.Transparent),
      center = center,
      radius = radius
    ),
    radius = radius,
    center = center
  )
}

private fun DrawScope.drawHill(
  baseFraction: Float,
  amplitudeFraction: Float,
  frequency: Float,
  phase: Float,
  color: Color
) {
  val w = size.width
  val h = size.height
  val steps = 32
  val path = Path()
  path.moveTo(0f, h)
  for (i in 0..steps) {
    val fraction = i.toFloat() / steps
    val x = w * fraction
    val y = h * baseFraction + h * amplitudeFraction * sin(TWO_PI * (frequency * fraction + phase))
    path.lineTo(x, y)
  }
  path.lineTo(w, h)
  path.close()
  drawPath(path = path, color = color)
}
