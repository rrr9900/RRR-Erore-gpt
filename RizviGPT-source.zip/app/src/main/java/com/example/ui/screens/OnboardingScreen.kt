package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.KoraOrb
import com.example.voice.OrbVisualState
import kotlinx.coroutines.launch

data class OnboardingSlide(
  val title: String,
  val subtitle: String,
  val cardPrompt: String,
  val cardAnswerLines: List<String>,
  val bgGradient: List<Color>,
  val isVoiceSlide: Boolean = false
)

val ONBOARDING_SLIDES = listOf(
  OnboardingSlide(
    title = "Turn photos\ninto ideas",
    subtitle = "Abstract any reference into varied minimalist logo concepts",
    cardPrompt = "Show me minimalist logos abstracting this photo in clean vector styles.",
    cardAnswerLines = listOf(
      "• Geometric chameleon crest in forest emerald",
      "• Minimal single-stroke continuous spiral outline",
      "• Modern hexagon emblem for outdoor & nature brands",
      "• Abstract leaf-silhouette monogram"
    ),
    bgGradient = listOf(Color(0xFFFFFFFF), Color(0xFFE0F2FE), Color(0xFFEDE9FE))
  ),
  OnboardingSlide(
    title = "Never stare at\na blank page",
    subtitle = "Instant story seeds, outlines, and imaginative brainstorming",
    cardPrompt = "I need help getting started on a short story. Can you give me some ideas?",
    cardAnswerLines = listOf(
      "1. The Forgotten City: Hikers stumble into an ancient sanctuary where time stands still.",
      "2. The Timekeeper's Currency: Seconds can be bought, bartered, or stolen across district borders.",
      "3. The Clockwork Forest: An astronomer discovers constellations encoded in tree rings."
    ),
    bgGradient = listOf(Color(0xFFFFFFFF), Color(0xFFFCE7F3), Color(0xFFE0E7FF))
  ),
  OnboardingSlide(
    title = "Understand\nwhat you see",
    subtitle = "Deep visual recognition for plants, tools, and everyday wonders",
    cardPrompt = "Can you give me information on this flower?",
    cardAnswerLines = listOf(
      "• Species: Spiraea japonica (Japanese Meadowsweet)",
      "• Characteristics: Dense clusters of delicate five-petal white blossoms",
      "• Care tips: Flourishes in well-drained soil with full morning sunlight",
      "• Note: Verify before culinary or medicinal use"
    ),
    bgGradient = listOf(Color(0xFFFFFFFF), Color(0xFFDCFCE7), Color(0xFFE0F2FE))
  ),
  OnboardingSlide(
    title = "Plan your\nnext goal",
    subtitle = "Structured training schedules and step-by-step roadmaps",
    cardPrompt = "How do I train for a marathon? Create a roadmap.",
    cardAnswerLines = listOf(
      "1. Establish Base Fitness: 3-4 runs per week, 3-5 miles comfortable pace",
      "2. Weekly Mileage Progression: Increase distance by no more than 10% each week",
      "3. Long Run Sundays: Build up to an 18-20 mile peak test run",
      "4. Taper Period: Reduce volume over the final 3 weeks before race day"
    ),
    bgGradient = listOf(Color(0xFFFFFFFF), Color(0xFFFEF3C7), Color(0xFFEDE9FE))
  ),
  OnboardingSlide(
    title = "Talk it\nout loud",
    subtitle = "Real-time conversational voice mode with expressive personas",
    cardPrompt = "Hey Rizvi, summarize the news and give me an upbeat start to the day.",
    cardAnswerLines = emptyList(),
    bgGradient = listOf(Color(0xFFFFFFFF), Color(0xFFDDD6FE), Color(0xFFFCE7F3)),
    isVoiceSlide = true
  ),
  OnboardingSlide(
    title = "Words in\nyour voice",
    subtitle = "Craft captions, emails, and pitches in your exact tone",
    cardPrompt = "Give me 5 witty captions for my beach getaway photo.",
    cardAnswerLines = listOf(
      "1. Out of office, into the turquoise.",
      "2. Currently busy doing absolutely nothing.",
      "3. Proof I did, in fact, relax.",
      "4. Vitamin Sea > everything else.",
      "5. Mentally still here. Physically... also here."
    ),
    bgGradient = listOf(Color(0xFFFFFFFF), Color(0xFFE0E7FF), Color(0xFFFEF3C7))
  ),
  OnboardingSlide(
    title = "Learn it\nyour way",
    subtitle = "Visual comic-style breakdowns for complex concepts",
    cardPrompt = "Show me the life cycle of a butterfly in simple comic book steps.",
    cardAnswerLines = listOf(
      "Panel 1: The Egg - Tiny dot on milkweed leaf",
      "Panel 2: The Caterpillar - Hungry feast and molting",
      "Panel 3: The Chrysalis - Secret metamorphosis inside",
      "Panel 4: The Butterfly - Unfurling wings to take flight"
    ),
    bgGradient = listOf(Color(0xFFFFFFFF), Color(0xFFF3E8FF), Color(0xFFDCFCE7))
  ),
  OnboardingSlide(
    title = "Make ideas\nvisible",
    subtitle = "Transform your imagination into vibrant digital artwork",
    cardPrompt = "Turn our photo into a vertical 16-bit pixel-art game scene with HUD.",
    cardAnswerLines = listOf(
      "• Rendering high-resolution 16-bit retro canvas...",
      "• Golden sunset palette with neon heart particles",
      "• Dynamic health bars and whimsical companion creature added",
      "• Visual art ready for download or iteration"
    ),
    bgGradient = listOf(Color(0xFFFFFFFF), Color(0xFFE0F2FE), Color(0xFFDDD6FE))
  )
)

@Composable
fun OnboardingScreen(
  onFinishOnboarding: () -> Unit
) {
  val pagerState = rememberPagerState(pageCount = { ONBOARDING_SLIDES.size })
  val coroutineScope = rememberCoroutineScope()
  val currentSlide = ONBOARDING_SLIDES[pagerState.currentPage]

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(currentSlide.bgGradient)
      )
      .statusBarsPadding()
      .navigationBarsPadding()
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 24.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // Top bar with Skip button
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 12.dp),
        horizontalArrangement = Arrangement.End
      ) {
        if (pagerState.currentPage < ONBOARDING_SLIDES.size - 1) {
          TextButton(onClick = onFinishOnboarding) {
            Text(
              text = "Skip",
              style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            )
          }
        } else {
          Spacer(modifier = Modifier.height(48.dp))
        }
      }

      // Horizontal Pager
      HorizontalPager(
        state = pagerState,
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth()
      ) { page ->
        val slide = ONBOARDING_SLIDES[page]
        Column(
          modifier = Modifier.fillMaxSize(),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          // 2-line large title
          Text(
            text = slide.title,
            style = MaterialTheme.typography.displayLarge.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 32.sp,
              lineHeight = 38.sp
            ),
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = slide.subtitle,
            style = MaterialTheme.typography.bodyMedium.copy(
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              fontSize = 14.sp
            ),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
          )

          Spacer(modifier = Modifier.height(28.dp))

          // Phone-style preview card
          Surface(
            modifier = Modifier
              .fillMaxWidth(0.92f)
              .clip(RoundedCornerShape(24.dp))
              .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                shape = RoundedCornerShape(24.dp)
              ),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
            tonalElevation = 3.dp,
            shape = RoundedCornerShape(24.dp)
          ) {
            Column(
              modifier = Modifier.padding(18.dp)
            ) {
              if (slide.isVoiceSlide) {
                // Voice mode special interactive preview
                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                  contentAlignment = Alignment.Center
                ) {
                  KoraOrb(
                    state = OrbVisualState.LISTENING,
                    amplitude = 0.6f,
                    orbSize = 150.dp
                  )
                }
                Text(
                  text = "\"Hey Rizvi, ready to create?\"",
                  style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                  ),
                  textAlign = TextAlign.Center,
                  modifier = Modifier.fillMaxWidth()
                )
                Text(
                  text = "Sol • Savvy & relaxed voice",
                  style = MaterialTheme.typography.bodySmall.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  ),
                  textAlign = TextAlign.Center,
                  modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                )
              } else {
                // User Prompt bubble preview
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.End
                ) {
                  Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(16.dp)
                  ) {
                    Text(
                      text = slide.cardPrompt,
                      style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontWeight = FontWeight.Medium
                      ),
                      modifier = Modifier.padding(12.dp)
                    )
                  }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Assistant reply preview
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                  slide.cardAnswerLines.forEach { line ->
                    Text(
                      text = line,
                      style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 18.sp
                      )
                    )
                  }
                }
              }
            }
          }
        }
      }

      // Bottom Row: Dots Pager & Next/Start CTA
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 20.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Pager dots indicator
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          repeat(ONBOARDING_SLIDES.size) { index ->
            val isSelected = pagerState.currentPage == index
            Box(
              modifier = Modifier
                .size(if (isSelected) 20.dp else 8.dp, 8.dp)
                .clip(CircleShape)
                .background(
                  if (isSelected) MaterialTheme.colorScheme.primary
                  else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)
                )
            )
          }
        }

        // Action Button
        val isLastPage = pagerState.currentPage == ONBOARDING_SLIDES.size - 1
        Button(
          onClick = {
            if (isLastPage) {
              onFinishOnboarding()
            } else {
              coroutineScope.launch {
                pagerState.animateScrollToPage(pagerState.currentPage + 1)
              }
            }
          },
          shape = CircleShape,
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary
          ),
          modifier = Modifier.height(48.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Text(
              text = if (isLastPage) "Get started" else "Next",
              style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
            )
            Icon(
              imageVector = if (isLastPage) Icons.Default.Check else Icons.AutoMirrored.Filled.ArrowForward,
              contentDescription = null,
              modifier = Modifier.size(18.dp)
            )
          }
        }
      }
    }
  }
}
