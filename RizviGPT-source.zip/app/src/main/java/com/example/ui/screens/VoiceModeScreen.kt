package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.KoraOrb
import com.example.viewmodel.KoraViewModel
import com.example.voice.VOICE_PERSONAS

@Composable
fun VoiceModeScreen(
  viewModel: KoraViewModel,
  onClose: () -> Unit
) {
  val settings by viewModel.settings.collectAsState()
  val visualState by viewModel.voiceOrbVisualState.collectAsState()
  val liveCaption by viewModel.voiceLiveCaption.collectAsState()
  val amplitude by viewModel.voiceManager.amplitude.collectAsState()
  val isListening by viewModel.voiceManager.isListening.collectAsState()

  var isMuted by remember { mutableStateOf(false) }
  var showLanguageMenu by remember { mutableStateOf(false) }
  var showIntelligenceMenu by remember { mutableStateOf(false) }

  val languages = listOf("Auto", "English", "Spanish", "French", "German", "Japanese", "Hindi", "Bengali")
  val intelligenceOptions = listOf("Instant", "Thoughtful")

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = listOf(
            Color(0xFF0F1115),
            Color(0xFF161922),
            Color(0xFF0D0F14)
          )
        )
      )
      .statusBarsPadding()
      .navigationBarsPadding()
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 24.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // Top header with close button and status
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Voice Mode",
            style = MaterialTheme.typography.titleMedium.copy(
              color = Color.White,
              fontWeight = FontWeight.Bold
            )
          )
          Text(
            text = "Barge in naturally anytime",
            style = MaterialTheme.typography.bodySmall.copy(
              color = Color(0xFFA4ABB8)
            )
          )
        }

        IconButton(
          onClick = {
            viewModel.closeVoiceMode()
            onClose()
          },
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Color(0xFF222630))
        ) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Close voice mode",
            tint = Color.White
          )
        }
      }

      Spacer(modifier = Modifier.weight(0.6f))

      // Central Animated 60fps Canvas Gradient Orb
      KoraOrb(
        state = visualState,
        amplitude = if (isMuted) 0f else amplitude,
        orbSize = 250.dp
      )

      Spacer(modifier = Modifier.height(28.dp))

      // Live Caption Display
      AnimatedVisibility(visible = liveCaption.isNotBlank()) {
        Surface(
          shape = RoundedCornerShape(18.dp),
          color = Color(0xFF1E222B).copy(alpha = 0.85f),
          modifier = Modifier.padding(horizontal = 8.dp)
        ) {
          Text(
            text = liveCaption,
            style = MaterialTheme.typography.bodyLarge.copy(
              color = Color(0xFFF2F4F8),
              fontSize = 15.sp,
              lineHeight = 22.sp
            ),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
            maxLines = 4
          )
        }
      }

      Spacer(modifier = Modifier.weight(1f))

      // Bottom Persona & Preferences Card
      Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        color = Color(0xFF181B21).copy(alpha = 0.95f),
        tonalElevation = 6.dp
      ) {
        Column(
          modifier = Modifier.padding(18.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          // Persona Carousel Row
          Text(
            text = "Voice Persona",
            style = MaterialTheme.typography.labelMedium.copy(
              color = Color(0xFFA4ABB8),
              fontWeight = FontWeight.SemiBold
            )
          )
          Spacer(modifier = Modifier.height(10.dp))

          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            items(VOICE_PERSONAS) { persona ->
              val isSelected = settings.voicePersona.equals(persona.name, ignoreCase = true)
              Surface(
                modifier = Modifier
                  .clip(RoundedCornerShape(16.dp))
                  .clickable {
                    viewModel.updateSettings(settings.copy(voicePersona = persona.name))
                    viewModel.voiceManager.speak("Hi, I'm ${persona.name}. Ready whenever you are.", persona.name, settings.speechRate)
                  },
                color = if (isSelected) Color(0xFF4F6BFF) else Color(0xFF222630),
                shape = RoundedCornerShape(16.dp)
              ) {
                Column(
                  modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                  horizontalAlignment = Alignment.CenterHorizontally
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = persona.name,
                      style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                      )
                    )
                    if (isSelected) {
                      Spacer(modifier = Modifier.width(4.dp))
                      Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                      )
                    }
                  }
                  Text(
                    text = persona.vibe,
                    style = MaterialTheme.typography.bodySmall.copy(
                      fontSize = 11.sp,
                      color = if (isSelected) Color(0xFFE0E7FF) else Color(0xFFA4ABB8)
                    )
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Dropdown settings row (Language & Intelligence)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            // Language selector
            Box(modifier = Modifier.weight(1f)) {
              Surface(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(14.dp))
                  .clickable { showLanguageMenu = true },
                color = Color(0xFF222630),
                shape = RoundedCornerShape(14.dp)
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      imageVector = Icons.Default.Language,
                      contentDescription = null,
                      tint = Color(0xFF8B7BFF),
                      modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = settings.language,
                      style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Medium,
                        color = Color.White
                      )
                    )
                  }
                  Text(
                    text = "▼",
                    fontSize = 9.sp,
                    color = Color(0xFFA4ABB8)
                  )
                }
              }

              DropdownMenu(
                expanded = showLanguageMenu,
                onDismissRequest = { showLanguageMenu = false }
              ) {
                languages.forEach { lang ->
                  DropdownMenuItem(
                    text = { Text(lang) },
                    onClick = {
                      viewModel.updateSettings(settings.copy(language = lang))
                      showLanguageMenu = false
                    }
                  )
                }
              }
            }

            // Intelligence mode selector
            Box(modifier = Modifier.weight(1f)) {
              Surface(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(14.dp))
                  .clickable { showIntelligenceMenu = true },
                color = Color(0xFF222630),
                shape = RoundedCornerShape(14.dp)
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      imageVector = Icons.Default.Psychology,
                      contentDescription = null,
                      tint = Color(0xFF8B7BFF),
                      modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = settings.responseStyle,
                      style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Medium,
                        color = Color.White
                      )
                    )
                  }
                  Text(
                    text = "▼",
                    fontSize = 9.sp,
                    color = Color(0xFFA4ABB8)
                  )
                }
              }

              DropdownMenu(
                expanded = showIntelligenceMenu,
                onDismissRequest = { showIntelligenceMenu = false }
              ) {
                intelligenceOptions.forEach { opt ->
                  DropdownMenuItem(
                    text = { Text(opt) },
                    onClick = {
                      viewModel.updateSettings(settings.copy(responseStyle = opt))
                      showIntelligenceMenu = false
                    }
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Mute toggle button
          IconButton(
            onClick = {
              isMuted = !isMuted
              if (isMuted) {
                viewModel.voiceManager.stopListening()
              } else {
                viewModel.retryVoiceListening()
              }
            },
            modifier = Modifier
              .size(56.dp)
              .clip(CircleShape)
              .background(if (isMuted) Color(0xFFD64545) else Color(0xFF2F9E6E))
          ) {
            Icon(
              imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
              contentDescription = if (isMuted) "Unmute" else "Mute",
              tint = Color.White,
              modifier = Modifier.size(26.dp)
            )
          }
        }
      }
      Spacer(modifier = Modifier.height(12.dp))
    }
  }
}
