package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.voice.OrbVisualState
import kotlin.math.PI
import kotlin.math.sin

@Composable
fun KoraOrb(
  modifier: Modifier = Modifier,
  state: OrbVisualState = OrbVisualState.IDLE,
  amplitude: Float = 0f,
  orbSize: Dp = 220.dp
) {
  val infiniteTransition = rememberInfiniteTransition(label = "orbTransition")

  // Gentle breathing oscillation
  val breathScale by infiniteTransition.animateFloat(
    initialValue = 0.94f,
    targetValue = 1.06f,
    animationSpec = infiniteRepeatable(
      animation = tween(2400, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "breathScale"
  )

  // Continuous swirling rotation
  val rotationAngle by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(
        durationMillis = when (state) {
          OrbVisualState.THINKING -> 2000
          OrbVisualState.SPEAKING -> 4000
          OrbVisualState.LISTENING -> 6000
          else -> 8000
        },
        easing = LinearEasing
      ),
      repeatMode = RepeatMode.Restart
    ),
    label = "rotationAngle"
  )

  // Speaking pulse
  val speakPulse by infiniteTransition.animateFloat(
    initialValue = 0.96f,
    targetValue = 1.12f,
    animationSpec = infiniteRepeatable(
      animation = tween(400, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "speakPulse"
  )

  // Dynamic amplitude smoothing
  val smoothAmplitude = remember { Animatable(0f) }
  LaunchedEffect(amplitude) {
    smoothAmplitude.animateTo(
      targetValue = amplitude,
      animationSpec = tween(100, easing = LinearEasing)
    )
  }

  Box(
    modifier = modifier.size(orbSize),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val center = Offset(size.width / 2f, size.height / 2f)
      val baseRadius = (size.minDimension / 2f) * 0.75f

      // Calculate state-driven radius multiplier
      val scaleFactor = when (state) {
        OrbVisualState.LISTENING -> 1.0f + (smoothAmplitude.value * 0.35f)
        OrbVisualState.SPEAKING -> speakPulse
        OrbVisualState.THINKING -> 1.0f + 0.05f * sin((rotationAngle * PI / 180f).toFloat())
        else -> breathScale
      }

      val currentRadius = baseRadius * scaleFactor

      // Outer ethereal glow aura
      val outerAuraColor = when (state) {
        OrbVisualState.LISTENING -> Color(0xFF7BD5B0).copy(alpha = 0.25f + smoothAmplitude.value * 0.35f)
        OrbVisualState.SPEAKING -> Color(0xFF2BA6A0).copy(alpha = 0.35f)
        OrbVisualState.THINKING -> Color(0xFFF4B6E0).copy(alpha = 0.30f)
        else -> Color(0xFF2BA6A0).copy(alpha = 0.18f)
      }

      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(outerAuraColor, Color.Transparent),
          center = center,
          radius = currentRadius * 1.5f
        ),
        radius = currentRadius * 1.5f,
        center = center
      )

      // Inner swirling core
      rotate(degrees = rotationAngle, pivot = center) {
        val orbColors = when (state) {
          OrbVisualState.THINKING -> listOf(
            Color(0xFFF4B6E0), // Radiant magenta
            Color(0xFF2BA6A0), // Violet
            Color(0xFF2F9E6E), // Indigo
            Color(0xFF7BD5B0), // Sky blue
            Color(0xFFFFFFFF)  // White heart
          )
          OrbVisualState.SPEAKING -> listOf(
            Color(0xFF2BA6A0),
            Color(0xFF2F9E6E),
            Color(0xFF7BD5B0),
            Color(0xFFE6F7EE),
            Color(0xFFFFFFFF)
          )
          OrbVisualState.LISTENING -> listOf(
            Color(0xFF2F9E6E),
            Color(0xFF7BD5B0),
            Color(0xFF2BA6A0),
            Color(0xFFCDEFE0),
            Color(0xFFFFFFFF)
          )
          else -> listOf(
            Color(0xFF3FAE7C),
            Color(0xFF2BA6A0),
            Color(0xFF9ADBC0),
            Color(0xFFE3F6EC),
            Color(0xFFFFFFFF)
          )
        }

        drawCircle(
          brush = Brush.sweepGradient(
            colors = orbColors,
            center = center
          ),
          radius = currentRadius,
          center = center
        )
      }

      // Center diffused highlight
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            Color.White.copy(alpha = 0.90f),
            Color(0xFFE3F6EC).copy(alpha = 0.50f),
            Color.Transparent
          ),
          center = center,
          radius = currentRadius * 0.65f
        ),
        radius = currentRadius * 0.65f,
        center = center
      )

      // Dynamic reactive ripple ring in listening mode
      if (state == OrbVisualState.LISTENING && smoothAmplitude.value > 0.1f) {
        val rippleRadius = currentRadius * (1.1f + smoothAmplitude.value * 0.4f)
        drawCircle(
          color = Color(0xFF7BD5B0).copy(alpha = (1f - smoothAmplitude.value).coerceIn(0.1f, 0.6f)),
          radius = rippleRadius,
          center = center,
          style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx())
        )
      }
    }
  }
}
