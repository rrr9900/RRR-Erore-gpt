package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

fun getKoraTypography(fontScaleMultiplier: Float = 1.0f): Typography {
  return Typography(
    displayLarge = TextStyle(
      fontFamily = FontFamily.Default,
      fontWeight = FontWeight.Bold,
      fontSize = (32 * fontScaleMultiplier).sp,
      lineHeight = (38 * fontScaleMultiplier).sp,
      letterSpacing = (-0.5).sp
    ),
    displayMedium = TextStyle(
      fontFamily = FontFamily.Default,
      fontWeight = FontWeight.SemiBold,
      fontSize = (28 * fontScaleMultiplier).sp,
      lineHeight = (34 * fontScaleMultiplier).sp,
      letterSpacing = (-0.25).sp
    ),
    headlineLarge = TextStyle(
      fontFamily = FontFamily.Default,
      fontWeight = FontWeight.SemiBold,
      fontSize = (24 * fontScaleMultiplier).sp,
      lineHeight = (30 * fontScaleMultiplier).sp
    ),
    headlineMedium = TextStyle(
      fontFamily = FontFamily.Default,
      fontWeight = FontWeight.SemiBold,
      fontSize = (20 * fontScaleMultiplier).sp,
      lineHeight = (28 * fontScaleMultiplier).sp
    ),
    headlineSmall = TextStyle(
      fontFamily = FontFamily.Default,
      fontWeight = FontWeight.SemiBold,
      fontSize = (18 * fontScaleMultiplier).sp,
      lineHeight = (24 * fontScaleMultiplier).sp
    ),
    titleLarge = TextStyle(
      fontFamily = FontFamily.Default,
      fontWeight = FontWeight.SemiBold,
      fontSize = (20 * fontScaleMultiplier).sp,
      lineHeight = (26 * fontScaleMultiplier).sp
    ),
    titleMedium = TextStyle(
      fontFamily = FontFamily.Default,
      fontWeight = FontWeight.Medium,
      fontSize = (16 * fontScaleMultiplier).sp,
      lineHeight = (22 * fontScaleMultiplier).sp
    ),
    bodyLarge = TextStyle(
      fontFamily = FontFamily.Default,
      fontWeight = FontWeight.Normal,
      fontSize = (16 * fontScaleMultiplier).sp,
      lineHeight = (24 * fontScaleMultiplier).sp,
      letterSpacing = 0.2.sp
    ),
    bodyMedium = TextStyle(
      fontFamily = FontFamily.Default,
      fontWeight = FontWeight.Normal,
      fontSize = (14 * fontScaleMultiplier).sp,
      lineHeight = (20 * fontScaleMultiplier).sp,
      letterSpacing = 0.2.sp
    ),
    bodySmall = TextStyle(
      fontFamily = FontFamily.Default,
      fontWeight = FontWeight.Normal,
      fontSize = (12 * fontScaleMultiplier).sp,
      lineHeight = (16 * fontScaleMultiplier).sp
    ),
    labelLarge = TextStyle(
      fontFamily = FontFamily.Default,
      fontWeight = FontWeight.SemiBold,
      fontSize = (14 * fontScaleMultiplier).sp,
      lineHeight = (20 * fontScaleMultiplier).sp
    ),
    labelMedium = TextStyle(
      fontFamily = FontFamily.Default,
      fontWeight = FontWeight.Medium,
      fontSize = (12 * fontScaleMultiplier).sp,
      lineHeight = (16 * fontScaleMultiplier).sp
    ),
    labelSmall = TextStyle(
      fontFamily = FontFamily.Default,
      fontWeight = FontWeight.Medium,
      fontSize = (11 * fontScaleMultiplier).sp,
      lineHeight = (14 * fontScaleMultiplier).sp
    )
  )
}

val Typography = getKoraTypography(1.0f)
