package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Kora Brand & Base Tokens
val KoraIndigo = Color(0xFF2F9E6E)
val KoraViolet = Color(0xFF8B7BFF)
val KoraPink = Color(0xFFF4B6E0)
val KoraSky = Color(0xFF70C3FF)

// Light Palette
val LightBackground = Color(0xFFF3FAF5)
val LightSurface = Color(0xFFF4FAF6)
val LightSurfaceVariant = Color(0xFFEDF1F8)
val LightPrimary = Color(0xFF4F6BFF)
val LightPrimaryContainer = Color(0xFFDDF1E4) // User chat bubble
val LightSecondary = Color(0xFF8B7BFF)
val LightSecondaryContainer = Color(0xFFEDE9FE)
val LightTertiary = Color(0xFFE879F9)
val LightTextPrimary = Color(0xFF14161A)
val LightTextSecondary = Color(0xFF5B6270)
val LightTextTertiary = Color(0xFF8A92A6)
val LightDivider = Color(0xFFE6E9EF)
val LightOutline = Color(0xFFD6DBE5)

// Dark Palette
val DarkBackground = Color(0xFF0A1812)
val DarkSurface = Color(0xFF12241D)
val DarkSurfaceVariant = Color(0xFF222630)
val DarkPrimary = Color(0xFF8FA2FF)
val DarkPrimaryContainer = Color(0xFF1C3A2E) // User chat bubble in dark
val DarkSecondary = Color(0xFFA597FF)
val DarkSecondaryContainer = Color(0xFF2E2A52)
val DarkTertiary = Color(0xFFF4B6E0)
val DarkTextPrimary = Color(0xFFF2F4F8)
val DarkTextSecondary = Color(0xFFA4ABB8)
val DarkTextTertiary = Color(0xFF6C7584)
val DarkDivider = Color(0xFF252932)
val DarkOutline = Color(0xFF323742)

// Functional Colors
val StatusSuccess = Color(0xFF2E9E6B)
val StatusError = Color(0xFFD64545)
val StatusWarning = Color(0xFFF59E0B)

// Accent Presets for Settings (nature palette first)
val AccentPresets = listOf(
  Color(0xFF2F9E6E), // Forest (Default)
  Color(0xFF2BA6A0), // Lagoon
  Color(0xFF4F9DDE), // Sky
  Color(0xFFEC4899), // Blossom
  Color(0xFFF59E0B)  // Sunrise
)
val AccentPresetNames = listOf("Forest", "Lagoon", "Sky", "Blossom", "Sunrise")
