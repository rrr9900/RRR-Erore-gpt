package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Brush
import androidx.compose.material.icons.outlined.FitnessCenter
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.LocalFlorist
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class SuggestionItem(
  val id: String,
  val title: String,
  val subtitle: String,
  val prompt: String,
  val icon: ImageVector,
  val needsImage: Boolean = false
)

val KORA_SUGGESTIONS = listOf(
  SuggestionItem(
    id = "story",
    title = "Brainstorm a story",
    subtitle = "Sci-fi time travel concept",
    prompt = "I need help with getting started on writing a short story. Can you give me some ideas?",
    icon = Icons.Outlined.Lightbulb
  ),
  SuggestionItem(
    id = "plant",
    title = "Identify what you see",
    subtitle = "Flora & nature inspection",
    prompt = "Can you give me detailed botanical information on this plant, its traits, and care tips?",
    icon = Icons.Outlined.LocalFlorist,
    needsImage = true
  ),
  SuggestionItem(
    id = "marathon",
    title = "Plan your next goal",
    subtitle = "16-week endurance training",
    prompt = "How do I train for a marathon? Create a structured weekly milestone plan.",
    icon = Icons.Outlined.FitnessCenter
  ),
  SuggestionItem(
    id = "captions",
    title = "Witty captions",
    subtitle = "5 punchy social lines",
    prompt = "Give me 5 witty, slightly smug caption ideas for this photo.",
    icon = Icons.Outlined.AutoAwesome,
    needsImage = true
  ),
  SuggestionItem(
    id = "comic",
    title = "Explain like a comic",
    subtitle = "Visual step breakdown",
    prompt = "I'm a visual learner, show me the life cycle of a butterfly in a simple comic book style with numbered steps.",
    icon = Icons.Outlined.MenuBook
  ),
  SuggestionItem(
    id = "pixelart",
    title = "Turn into pixel art",
    subtitle = "16-bit retro game scene",
    prompt = "Turn my photo into a vertical 16-bit pixel-art game scene with HUD showing an uplifting climax.",
    icon = Icons.Outlined.Image,
    needsImage = true
  ),
  SuggestionItem(
    id = "logos",
    title = "Logo ideas from photo",
    subtitle = "Minimalist vector concepts",
    prompt = "Show me 16-20 minimalist logos abstracting this photo in varied clean vector styles.",
    icon = Icons.Outlined.Brush,
    needsImage = true
  ),
  SuggestionItem(
    id = "palette",
    title = "Harmonic color palette",
    subtitle = "Design theme extraction",
    prompt = "Extract an aesthetic 5-color design palette with hex codes and mood description from this scene.",
    icon = Icons.Outlined.Palette,
    needsImage = true
  )
)

@Composable
fun SuggestionChipsRow(
  modifier: Modifier = Modifier,
  onSuggestionClick: (SuggestionItem) -> Unit
) {
  LazyRow(
    modifier = modifier.fillMaxWidth(),
    contentPadding = PaddingValues(horizontal = 16.dp),
    horizontalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    items(KORA_SUGGESTIONS, key = { it.id }) { item ->
      Surface(
        modifier = Modifier
          .width(180.dp)
          .clip(RoundedCornerShape(20.dp))
          .clickable { onSuggestionClick(item) },
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f),
        tonalElevation = 1.dp,
        shape = RoundedCornerShape(20.dp)
      ) {
        Column(
          modifier = Modifier.padding(14.dp)
        ) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = item.icon,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(20.dp)
            )
          }
          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = item.title,
            style = MaterialTheme.typography.titleSmall.copy(
              fontWeight = FontWeight.SemiBold,
              fontSize = 14.sp
            ),
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = item.subtitle,
            style = MaterialTheme.typography.bodySmall.copy(
              fontSize = 12.sp
            ),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
          )
        }
      }
    }
  }
}
