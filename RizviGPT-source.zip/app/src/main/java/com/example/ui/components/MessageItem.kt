package com.example.ui.components

import android.content.Intent
import android.graphics.BitmapFactory
import android.util.Base64
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.local.MessageEntity
import java.io.File

@Composable
fun MessageItem(
  message: MessageEntity,
  isSpeaking: Boolean = false,
  onSpeak: (String) -> Unit = {},
  onRegenerate: () -> Unit = {},
  onFeedback: (Int) -> Unit = {},
  onImageClick: (String) -> Unit = {}
) {
  val context = LocalContext.current
  val clipboardManager = LocalClipboardManager.current
  val isUser = message.role == "user"

  if (isUser) {
    // User Message: Right-aligned tinted bubble
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 4.dp),
      horizontalAlignment = Alignment.End
    ) {
      // Attached image thumbnails if any
      val imageList = remember(message.imageUris) {
        if (message.imageUris.isBlank()) emptyList()
        else message.imageUris.split(",").map { it.trim() }.filter { it.isNotEmpty() }
      }

      if (imageList.isNotEmpty()) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.padding(bottom = 6.dp)
        ) {
          imageList.forEach { path ->
            AsyncImage(
              model = ImageRequest.Builder(context)
                .data(File(path))
                .crossfade(true)
                .build(),
              contentDescription = "Attached photo",
              modifier = Modifier
                .size(100.dp)
                .clip(RoundedCornerShape(16.dp))
                .clickable { onImageClick(path) },
              contentScale = ContentScale.Crop
            )
          }
        }
      }

      // Bubble
      Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(
          topStart = 20.dp,
          topEnd = 20.dp,
          bottomStart = 20.dp,
          bottomEnd = 4.dp
        ),
        modifier = Modifier.widthIn(max = 290.dp)
      ) {
        Text(
          text = message.content,
          style = MaterialTheme.typography.bodyLarge.copy(
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            lineHeight = 22.sp
          ),
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        )
      }
    }
  } else {
    // Assistant Message: Left-aligned plain layout (no bubble)
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 8.dp),
      horizontalAlignment = Alignment.Start
    ) {
      // If there is a generated image (new: stored as a file, old chats: base64 text)
      if (!message.generatedImageBase64.isNullOrBlank()) {
        val stored = message.generatedImageBase64
        val imagePath = if (stored.startsWith("file:")) stored.removePrefix("file:") else null
        val bitmap = remember(stored) {
          try {
            if (imagePath != null) {
              BitmapFactory.decodeFile(imagePath)
            } else {
              val bytes = Base64.decode(stored, Base64.DEFAULT)
              BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }
          } catch (_: Exception) {
            null
          }
        }

        if (bitmap != null) {
          val ratio = if (bitmap.height > 0) bitmap.width.toFloat() / bitmap.height.toFloat() else 1f
          Surface(
            shape = RoundedCornerShape(20.dp),
            tonalElevation = 2.dp,
            modifier = Modifier
              .fillMaxWidth(0.88f)
              .clip(RoundedCornerShape(20.dp))
          ) {
            Image(
              bitmap = bitmap.asImageBitmap(),
              contentDescription = "AI Generated Artwork",
              contentScale = ContentScale.Fit,
              modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(ratio.coerceIn(0.4f, 2.5f))
                .then(
                  if (imagePath != null) Modifier.clickable { onImageClick(imagePath) } else Modifier
                )
            )
          }
          Row(
            modifier = Modifier.padding(top = 4.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            TextButton(
              onClick = {
                val ok = saveBitmapToGallery(context, bitmap)
                Toast.makeText(
                  context,
                  if (ok) "Saved to your gallery" else "Could not save the picture",
                  Toast.LENGTH_SHORT
                ).show()
              }
            ) {
              Icon(
                imageVector = Icons.Default.Download,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text("Save picture")
            }
          }
        } else {
          Text(
            text = "The picture is no longer available on this device.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp)
          )
        }
      }

      // Content or loading indicator
      if (message.status == "streaming" && message.content.isEmpty()) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(vertical = 8.dp)
        ) {
          CircularProgressIndicator(
            modifier = Modifier.size(18.dp),
            strokeWidth = 2.dp,
            color = MaterialTheme.colorScheme.primary
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Rizvi@gpt is thinking...",
            style = MaterialTheme.typography.bodyMedium.copy(
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          )
        }
      } else {
        MarkdownText(
          text = message.content,
          isStreaming = message.status == "streaming"
        )
      }

      // Action row under assistant replies
      if (message.status != "streaming" && message.content.isNotEmpty()) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(4.dp),
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(top = 6.dp)
        ) {
          IconButton(
            onClick = {
              clipboardManager.setText(AnnotatedString(message.content))
              Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              imageVector = Icons.Default.ContentCopy,
              contentDescription = "Copy message",
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(16.dp)
            )
          }

          IconButton(
            onClick = { onSpeak(message.content) },
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              imageVector = Icons.Default.VolumeUp,
              contentDescription = "Read aloud",
              tint = if (isSpeaking) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(17.dp)
            )
          }

          IconButton(
            onClick = onRegenerate,
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Refresh,
              contentDescription = "Regenerate",
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(17.dp)
            )
          }

          IconButton(
            onClick = { onFeedback(if (message.feedback == 1) 0 else 1) },
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              imageVector = if (message.feedback == 1) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
              contentDescription = "Helpful",
              tint = if (message.feedback == 1) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(16.dp)
            )
          }

          IconButton(
            onClick = { onFeedback(if (message.feedback == -1) 0 else -1) },
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              imageVector = if (message.feedback == -1) Icons.Filled.ThumbDown else Icons.Outlined.ThumbDown,
              contentDescription = "Not helpful",
              tint = if (message.feedback == -1) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(16.dp)
            )
          }

          IconButton(
            onClick = {
              val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, message.content)
                type = "text/plain"
              }
              context.startActivity(Intent.createChooser(shareIntent, "Share Rizvi@gpt answer"))
            },
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Share,
              contentDescription = "Share",
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(16.dp)
            )
          }
        }
      }
    }
  }
}
