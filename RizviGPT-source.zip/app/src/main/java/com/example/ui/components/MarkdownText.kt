package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MarkdownText(
  text: String,
  modifier: Modifier = Modifier,
  textColor: Color = MaterialTheme.colorScheme.onSurface,
  isStreaming: Boolean = false
) {
  val lines = text.split("\n")
  val context = LocalContext.current
  val clipboardManager = LocalClipboardManager.current

  Column(
    modifier = modifier,
    verticalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    var inCodeBlock = false
    val codeBlockBuilder = StringBuilder()
    var codeLanguage = ""

    for ((index, line) in lines.withIndex()) {
      if (line.trim().startsWith("```")) {
        if (!inCodeBlock) {
          inCodeBlock = true
          codeLanguage = line.trim().removePrefix("```").trim()
          codeBlockBuilder.clear()
        } else {
          inCodeBlock = false
          val codeContent = codeBlockBuilder.toString()
          CodeBlockView(
            code = codeContent,
            language = codeLanguage,
            onCopy = {
              clipboardManager.setText(AnnotatedString(codeContent))
              Toast.makeText(context, "Code copied", Toast.LENGTH_SHORT).show()
            }
          )
        }
        continue
      }

      if (inCodeBlock) {
        codeBlockBuilder.append(line).append("\n")
        continue
      }

      val trimmed = line.trim()
      when {
        trimmed.startsWith("### ") -> {
          Text(
            text = parseInlineMarkdown(trimmed.removePrefix("### ")),
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 17.sp,
              color = textColor
            ),
            modifier = Modifier.padding(top = 4.dp)
          )
        }
        trimmed.startsWith("## ") -> {
          Text(
            text = parseInlineMarkdown(trimmed.removePrefix("## ")),
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 19.sp,
              color = textColor
            ),
            modifier = Modifier.padding(top = 6.dp)
          )
        }
        trimmed.startsWith("# ") -> {
          Text(
            text = parseInlineMarkdown(trimmed.removePrefix("# ")),
            style = MaterialTheme.typography.headlineSmall.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 22.sp,
              color = textColor
            ),
            modifier = Modifier.padding(top = 8.dp)
          )
        }
        trimmed.startsWith("- ") || trimmed.startsWith("* ") -> {
          Row(
            modifier = Modifier.fillMaxWidth().padding(start = 4.dp),
            verticalAlignment = Alignment.Top
          ) {
            Box(
              modifier = Modifier
                .padding(top = 8.dp, end = 8.dp)
                .size(6.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
            )
            Text(
              text = parseInlineMarkdown(trimmed.substring(2)),
              style = MaterialTheme.typography.bodyLarge.copy(color = textColor),
              modifier = Modifier.weight(1f)
            )
          }
        }
        Regex("^\\d+\\.\\s+.*").matches(trimmed) -> {
          val dotIndex = trimmed.indexOf('.')
          val number = trimmed.substring(0, dotIndex + 1)
          val content = trimmed.substring(dotIndex + 1).trim()
          Row(
            modifier = Modifier.fillMaxWidth().padding(start = 4.dp),
            verticalAlignment = Alignment.Top
          ) {
            Text(
              text = number,
              style = MaterialTheme.typography.bodyLarge.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              ),
              modifier = Modifier.width(28.dp)
            )
            Text(
              text = parseInlineMarkdown(content),
              style = MaterialTheme.typography.bodyLarge.copy(color = textColor),
              modifier = Modifier.weight(1f)
            )
          }
        }
        trimmed.isEmpty() -> {
          Spacer(modifier = Modifier.height(2.dp))
        }
        else -> {
          Text(
            text = parseInlineMarkdown(line),
            style = MaterialTheme.typography.bodyLarge.copy(
              color = textColor,
              lineHeight = 24.sp
            )
          )
        }
      }
    }

    if (inCodeBlock) {
      val codeContent = codeBlockBuilder.toString()
      CodeBlockView(
        code = codeContent,
        language = codeLanguage,
        onCopy = {
          clipboardManager.setText(AnnotatedString(codeContent))
          Toast.makeText(context, "Code copied", Toast.LENGTH_SHORT).show()
        }
      )
    }

    if (isStreaming) {
      Box(
        modifier = Modifier
          .size(width = 8.dp, height = 18.dp)
          .clip(RoundedCornerShape(2.dp))
          .background(MaterialTheme.colorScheme.primary)
      )
    }
  }
}

@Composable
private fun CodeBlockView(
  code: String,
  language: String,
  onCopy: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .background(MaterialTheme.colorScheme.surfaceVariant)
      .padding(12.dp)
  ) {
    Column {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (language.isNotBlank()) language.uppercase() else "CODE",
          style = MaterialTheme.typography.labelSmall.copy(
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
        )
        IconButton(
          onClick = onCopy,
          modifier = Modifier.size(28.dp)
        ) {
          Icon(
            imageVector = Icons.Default.ContentCopy,
            contentDescription = "Copy code",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(16.dp)
          )
        }
      }
      Spacer(modifier = Modifier.height(4.dp))
      Box(modifier = Modifier.horizontalScroll(rememberScrollState())) {
        Text(
          text = code.trimEnd(),
          style = MaterialTheme.typography.bodyMedium.copy(
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        )
      }
    }
  }
}

private fun parseInlineMarkdown(text: String): AnnotatedString {
  return buildAnnotatedString {
    var i = 0
    while (i < text.length) {
      if (text.startsWith("**", i)) {
        val end = text.indexOf("**", i + 2)
        if (end != -1) {
          pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
          append(text.substring(i + 2, end))
          pop()
          i = end + 2
          continue
        }
      } else if (text.startsWith("`", i)) {
        val end = text.indexOf("`", i + 1)
        if (end != -1) {
          pushStyle(SpanStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp))
          append(text.substring(i + 1, end))
          pop()
          i = end + 1
          continue
        }
      }
      append(text[i])
      i++
    }
  }
}
