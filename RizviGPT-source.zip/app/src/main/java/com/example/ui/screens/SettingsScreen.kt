package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.ui.theme.AccentPresetNames
import com.example.ui.theme.AccentPresets
import com.example.viewmodel.KoraViewModel
import com.example.voice.VOICE_PERSONAS
import org.json.JSONArray
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
  viewModel: KoraViewModel,
  onBack: () -> Unit
) {
  val settings by viewModel.settings.collectAsState()
  val chats by viewModel.chats.collectAsState()
  val context = LocalContext.current

  val clipboardManager = LocalClipboardManager.current
  var enteredApiKey by remember(settings.apiKey) { mutableStateOf(settings.apiKey) }
  var showApiKey by remember { mutableStateOf(false) }
  var showResetDialog by remember { mutableStateOf(false) }
  val exportScope = rememberCoroutineScope()
  val exportLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.CreateDocument("application/json")
  ) { uri: Uri? ->
    if (uri != null) {
      exportScope.launch {
        val ok = try {
          val json = viewModel.buildExportJson()
          withContext(Dispatchers.IO) {
            context.contentResolver.openOutputStream(uri)?.use { out ->
              out.write(json.toByteArray(Charsets.UTF_8))
            } != null
          }
        } catch (_: Exception) {
          false
        }
        Toast.makeText(
          context,
          if (ok) "Chats exported" else "Export failed",
          Toast.LENGTH_SHORT
        ).show()
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .statusBarsPadding()
      .navigationBarsPadding()
  ) {
    TopAppBar(
      title = {
        Text(
          text = "Settings",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )
      },
      navigationIcon = {
        IconButton(onClick = onBack) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back"
          )
        }
      },
      colors = TopAppBarDefaults.topAppBarColors(
        containerColor = MaterialTheme.colorScheme.background
      )
    )

    Column(
      modifier = Modifier
        .weight(1f)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
      // 1. Profile Section
      SettingsSection(title = "Profile") {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(52.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = settings.userName.take(1).uppercase(),
              style = MaterialTheme.typography.headlineMedium.copy(
                color = Color.White,
                fontWeight = FontWeight.Bold
              )
            )
          }
          Spacer(modifier = Modifier.width(16.dp))
          OutlinedTextField(
            value = settings.userName,
            onValueChange = { viewModel.updateSettings(settings.copy(userName = it)) },
            label = { Text("Your Name") },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1f)
          )
        }
      }

      // 2. Gemini AI API Key Section
      SettingsSection(title = "Gemini AI API Key") {
        val hasCustomKey = settings.apiKey.isNotBlank()
        val buildKey = try { BuildConfig.GEMINI_API_KEY } catch (_: Exception) { "" }
        val hasEnvKey = buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY"

        // Status indicator card
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = when {
            hasCustomKey -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            hasEnvKey -> MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
            else -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
          },
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Box(
              modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(
                  when {
                    hasCustomKey -> Color(0xFF4CAF50)
                    hasEnvKey -> MaterialTheme.colorScheme.primary
                    else -> MaterialTheme.colorScheme.error
                  }
                )
            )
            Text(
              text = when {
                hasCustomKey -> "Custom Key Active (Saved securely on device)"
                hasEnvKey -> "Using AI Studio Project Secret Key"
                else -> "No API Key Set (Add your key below)"
              },
              style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = enteredApiKey,
          onValueChange = { enteredApiKey = it },
          label = { Text("Gemini API Key") },
          placeholder = { Text("AIzaSy...") },
          leadingIcon = {
            Icon(
              imageVector = Icons.Default.Key,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary
            )
          },
          trailingIcon = {
            Row(verticalAlignment = Alignment.CenterVertically) {
              if (enteredApiKey.isNotEmpty()) {
                IconButton(onClick = { enteredApiKey = "" }) {
                  Icon(
                    imageVector = Icons.Default.Clear,
                    contentDescription = "Clear",
                    modifier = Modifier.size(18.dp)
                  )
                }
              }
              IconButton(onClick = { showApiKey = !showApiKey }) {
                Icon(
                  imageVector = if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                  contentDescription = if (showApiKey) "Hide Key" else "Show Key",
                  modifier = Modifier.size(20.dp)
                )
              }
            }
          },
          visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          OutlinedButton(
            onClick = {
              val clipText = clipboardManager.getText()?.text
              if (!clipText.isNullOrBlank()) {
                enteredApiKey = clipText.trim()
                Toast.makeText(context, "Key pasted from clipboard", Toast.LENGTH_SHORT).show()
              } else {
                Toast.makeText(context, "Clipboard is empty", Toast.LENGTH_SHORT).show()
              }
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1f)
          ) {
            Icon(
              imageVector = Icons.Default.ContentPaste,
              contentDescription = null,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("Paste", fontSize = 13.sp)
          }

          Button(
            onClick = {
              val keyToSave = enteredApiKey.trim()
              viewModel.updateSettings(settings.copy(apiKey = keyToSave))
              Toast.makeText(
                context,
                if (keyToSave.isNotBlank()) "API Key saved successfully!" else "API Key cleared",
                Toast.LENGTH_SHORT
              ).show()
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1f)
          ) {
            Icon(
              imageVector = Icons.Default.Check,
              contentDescription = null,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("Save", fontSize = 13.sp)
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        TextButton(
          onClick = {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey"))
            context.startActivity(intent)
          },
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(
            imageVector = Icons.Default.OpenInNew,
            contentDescription = null,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Get a free Gemini API Key from Google AI Studio",
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
          )
        }
      }

      // 2. Appearance Section
      SettingsSection(title = "Appearance") {
        Text(
          text = "Theme mode",
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          listOf("system" to "System", "light" to "Light", "dark" to "Dark").forEach { (mode, label) ->
            val isSelected = settings.themeMode == mode
            OutlinedButton(
              onClick = { viewModel.updateSettings(settings.copy(themeMode = mode)) },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.weight(1f),
              colors = ButtonDefaults.outlinedButtonColors(
                containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
              )
            ) {
              Text(
                text = label,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))
        Text(
          text = "Accent Color",
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceAround
        ) {
          AccentPresets.forEachIndexed { index, color ->
            val isSelected = settings.accentIndex == index
            Box(
              modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(color)
                .border(
                  width = if (isSelected) 3.dp else 1.dp,
                  color = if (isSelected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                  shape = CircleShape
                )
                .clickable {
                  viewModel.updateSettings(settings.copy(accentIndex = index))
                },
              contentAlignment = Alignment.Center
            ) {
              if (isSelected) {
                Icon(
                  imageVector = Icons.Default.Check,
                  contentDescription = null,
                  tint = Color.White,
                  modifier = Modifier.size(20.dp)
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))
        Text(
          text = "Font Size",
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          listOf("small" to "Small", "medium" to "Medium", "large" to "Large").forEach { (size, label) ->
            val isSelected = settings.fontSize == size
            OutlinedButton(
              onClick = { viewModel.updateSettings(settings.copy(fontSize = size)) },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.weight(1f),
              colors = ButtonDefaults.outlinedButtonColors(
                containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
              )
            ) {
              Text(
                text = label,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }
      }

      // 3. Voice & Speech Section
      SettingsSection(title = "Voice Persona & Speech") {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          VOICE_PERSONAS.forEach { persona ->
            val isSelected = settings.voicePersona.equals(persona.name, ignoreCase = true)
            Surface(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .clickable {
                  viewModel.updateSettings(settings.copy(voicePersona = persona.name))
                  viewModel.voiceManager.speak("Hello, this is ${persona.name}.", persona.name, settings.speechRate)
                },
              color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              shape = RoundedCornerShape(14.dp)
            ) {
              Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column {
                  Text(
                    text = persona.name,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                  )
                  Text(
                    text = persona.vibe,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
                Icon(
                  imageVector = Icons.Default.VolumeUp,
                  contentDescription = "Test Voice",
                  tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.size(20.dp)
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Speech Rate",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
          )
          Text(
            text = String.format("%.2fx", settings.speechRate),
            style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.primary)
          )
        }
        Slider(
          value = settings.speechRate,
          onValueChange = { viewModel.updateSettings(settings.copy(speechRate = it)) },
          valueRange = 0.75f..1.5f,
          steps = 5
        )
      }

      // 4. Personalization & Tone
      SettingsSection(title = "Personalization") {
        OutlinedTextField(
          value = settings.aboutYou,
          onValueChange = { viewModel.updateSettings(settings.copy(aboutYou = it)) },
          label = { Text("About You") },
          placeholder = { Text("E.g., software engineer, photography enthusiast, marathon runner") },
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth(),
          maxLines = 3
        )

        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "Preferred Tone",
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
        )
        Spacer(modifier = Modifier.height(8.dp))
        val tones = listOf("Friendly", "Concise", "Professional", "Playful", "Sigma")
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          tones.forEach { tone ->
            val isSelected = settings.tone == tone
            OutlinedButton(
              onClick = { viewModel.updateSettings(settings.copy(tone = tone)) },
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.outlinedButtonColors(
                containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
              )
            ) {
              Text(
                text = tone,
                fontSize = 12.sp,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }
      }

      // 5. Data & Privacy
      SettingsSection(title = "Data & Privacy") {
        // Export chats
        OutlinedButton(
          onClick = { exportLauncher.launch("rizvigpt_chats.json") },
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(imageVector = Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Export all chats (JSON)")
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Reset all data
        Button(
          onClick = { showResetDialog = true },
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.error
          ),
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Reset all chats & data")
        }
      }

      // About
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "Rizvi@gpt AI Assistant v1.1",
          style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
        )
        Text(
          text = "Your personal AI assistant, powered by Gemini",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }

  if (showResetDialog) {
    AlertDialog(
      onDismissRequest = { showResetDialog = false },
      title = { Text("Reset all data?") },
      text = { Text("This will permanently clear all saved conversations and preferences from this device.") },
      confirmButton = {
        TextButton(
          onClick = {
            viewModel.resetAllData()
            showResetDialog = false
            Toast.makeText(context, "All data reset", Toast.LENGTH_SHORT).show()
          }
        ) {
          Text("Reset", color = MaterialTheme.colorScheme.error)
        }
      },
      dismissButton = {
        TextButton(onClick = { showResetDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }
}

@Composable
private fun SettingsSection(
  title: String,
  content: @Composable () -> Unit
) {
  Surface(
    shape = RoundedCornerShape(20.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(18.dp)) {
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary
        )
      )
      Spacer(modifier = Modifier.height(14.dp))
      content()
    }
  }
}
