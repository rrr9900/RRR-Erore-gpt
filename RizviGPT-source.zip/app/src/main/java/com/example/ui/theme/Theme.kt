package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

fun createKoraColorScheme(
  isDark: Boolean,
  accentColor: Color = KoraIndigo
) = if (isDark) {
  darkColorScheme(
    primary = accentColor,
    onPrimary = Color.White,
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = DarkTextPrimary,
    secondary = DarkSecondary,
    onSecondary = Color.White,
    secondaryContainer = DarkSecondaryContainer,
    onSecondaryContainer = DarkTextPrimary,
    tertiary = DarkTertiary,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkOutline,
    outlineVariant = DarkDivider
  )
} else {
  lightColorScheme(
    primary = accentColor,
    onPrimary = Color.White,
    primaryContainer = LightPrimaryContainer,
    onPrimaryContainer = LightTextPrimary,
    secondary = LightSecondary,
    onSecondary = Color.White,
    secondaryContainer = LightSecondaryContainer,
    onSecondaryContainer = LightTextPrimary,
    tertiary = LightTertiary,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightTextSecondary,
    outline = LightOutline,
    outlineVariant = LightDivider
  )
}

@Composable
fun KoraTheme(
  themeMode: String = "system", // "system", "light", "dark"
  accentColor: Color = KoraIndigo,
  fontScaleMultiplier: Float = 1.0f,
  content: @Composable () -> Unit
) {
  val isDark = when (themeMode) {
    "dark" -> true
    "light" -> false
    else -> isSystemInDarkTheme()
  }

  val colorScheme = createKoraColorScheme(isDark, accentColor)
  val typography = getKoraTypography(fontScaleMultiplier)

  MaterialTheme(
    colorScheme = colorScheme,
    typography = typography,
    content = content
  )
}
