package com.example.data.remote

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.example.BuildConfig
import com.example.data.local.UserSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.TimeUnit

sealed class GeminiStreamEvent {
  data class Chunk(val text: String) : GeminiStreamEvent()
  data class ImageResult(val base64Image: String, val caption: String) : GeminiStreamEvent()
  data class Finished(val fullText: String) : GeminiStreamEvent()
  data class Error(val message: String) : GeminiStreamEvent()
}

class GeminiClient {
  private val client: OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(60, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .writeTimeout(60, TimeUnit.SECONDS)
    .build()

  // Image generation can take longer than a normal chat reply.
  private val imageClient: OkHttpClient = client.newBuilder()
    .readTimeout(150, TimeUnit.SECONDS)
    .build()

  private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

  fun getApiKey(customApiKey: String? = null): String {
    if (!customApiKey.isNullOrBlank()) {
      return customApiKey.trim()
    }
    val key = try {
      BuildConfig.GEMINI_API_KEY
    } catch (_: Exception) {
      ""
    }
    return if (key == "MY_GEMINI_API_KEY" || key.isBlank()) "" else key.trim()
  }

  suspend fun streamChat(
    messages: List<Pair<String, String>>, // role ("user"/"model") to text
    imagePaths: List<String> = emptyList(),
    settings: UserSettings,
    onChunk: (String) -> Unit
  ): Result<String> = withContext(Dispatchers.IO) {
    val apiKey = getApiKey(settings.apiKey)
    if (apiKey.isBlank()) {
      val fallback = "Gemini API key is not configured. Please add your Gemini API key in Settings (Gemini AI API Key)."
      onChunk(fallback)
      return@withContext Result.success(fallback)
    }

    val candidateModels = if (settings.responseStyle == "Thoughtful") {
      listOf("gemini-3.1-pro-preview", "gemini-2.5-flash", "gemini-flash-latest")
    } else {
      listOf("gemini-2.5-flash", "gemini-flash-latest", "gemini-3.1-flash-lite-preview", "gemini-3.5-flash")
    }

    try {
      val requestBodyJson = JSONObject()

      // System instruction
      val systemInstruction = buildSystemPrompt(settings)
      val sysParts = JSONArray().put(JSONObject().put("text", systemInstruction))
      requestBodyJson.put("systemInstruction", JSONObject().put("parts", sysParts))

      // Contents array
      val contentsArray = JSONArray()
      messages.forEachIndexed { index, (role, text) ->
        val contentObj = JSONObject()
        contentObj.put("role", if (role == "user") "user" else "model")

        val partsArray = JSONArray()
        // If this is the latest user message and has images
        if (index == messages.lastIndex && role == "user" && imagePaths.isNotEmpty()) {
          for (path in imagePaths.take(4)) {
            val base64 = encodeImageToBase64(path)
            if (base64 != null) {
              val inlineData = JSONObject()
                .put("mimeType", "image/jpeg")
                .put("data", base64)
              partsArray.put(JSONObject().put("inlineData", inlineData))
            }
          }
        }
        partsArray.put(JSONObject().put("text", text))
        contentObj.put("parts", partsArray)
        contentsArray.put(contentObj)
      }
      requestBodyJson.put("contents", contentsArray)

      // Generation config
      val config = JSONObject()
        .put("temperature", 0.7)
        .put("topP", 0.95)
      requestBodyJson.put("generationConfig", config)

      var lastError: Exception? = null

      for (modelName in candidateModels) {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:streamGenerateContent?alt=sse"
        try {
          val request = Request.Builder()
            .url(url)
            .header("x-goog-api-key", apiKey)
            .post(requestBodyJson.toString().toRequestBody(jsonMediaType))
            .build()

          val response = client.newCall(request).execute()
          if (!response.isSuccessful) {
            val errBody = response.body?.string() ?: ""
            val isHighDemandOrOverload = response.code == 503 ||
                response.code == 404 ||
                response.code == 429 ||
                response.code == 500 ||
                errBody.contains("high demand", ignoreCase = true) ||
                errBody.contains("overloaded", ignoreCase = true) ||
                errBody.contains("quota", ignoreCase = true) ||
                errBody.contains("resource exhausted", ignoreCase = true) ||
                errBody.contains("not found", ignoreCase = true)

            if (isHighDemandOrOverload && modelName != candidateModels.last()) {
              // Automatically fallback to alternative model
              continue
            }
            val errMsg = parseErrorMessage(response.code, errBody)
            return@withContext Result.failure(Exception(errMsg))
          }

          val fullResponse = StringBuilder()
          var blockReason = ""
          response.body?.byteStream()?.bufferedReader()?.use { reader ->
            var line: String?
            while (reader.readLine().also { line = it } != null) {
              val rawLine = line?.trim() ?: continue
              if (!rawLine.startsWith("data:")) continue
              val jsonPayload = rawLine.removePrefix("data:").trim()
              if (jsonPayload.isEmpty() || jsonPayload == "[DONE]") continue

              try {
                val chunkJson = JSONObject(jsonPayload)
                val feedbackReason = chunkJson.optJSONObject("promptFeedback")?.optString("blockReason", "") ?: ""
                if (feedbackReason.isNotEmpty()) blockReason = feedbackReason
                val candidates = chunkJson.optJSONArray("candidates")
                val firstCandidate = candidates?.optJSONObject(0)
                val content = firstCandidate?.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null) {
                  for (partIndex in 0 until parts.length()) {
                    val chunkText = parts.optJSONObject(partIndex)?.optString("text", "")
                    if (!chunkText.isNullOrEmpty()) {
                      fullResponse.append(chunkText)
                      onChunk(chunkText)
                    }
                  }
                }
              } catch (_: Exception) {
                // Ignore parse errors on trailing or heartbeat tokens
              }
            }
          }

          if (fullResponse.isEmpty()) {
            val why = if (blockReason.isNotEmpty()) " (blocked: $blockReason)" else ""
            return@withContext Result.failure(
              Exception("The AI returned an empty answer$why. Please rephrase your message and try again.")
            )
          }
          return@withContext Result.success(fullResponse.toString())
        } catch (e: Exception) {
          lastError = e
          if (modelName != candidateModels.last()) {
            continue
          }
        }
      }

      return@withContext Result.failure(lastError ?: Exception("Unable to connect to AI service. Please check your network or try again."))
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun generateImage(
    prompt: String,
    referenceImagePath: String? = null,
    customApiKey: String? = null,
    styleId: String = "photoreal",
    aspectRatio: String = "1:1"
  ): Result<Pair<String, String>> = withContext(Dispatchers.IO) {
    val apiKey = getApiKey(customApiKey)
    if (apiKey.isBlank()) {
      return@withContext Result.failure(Exception("Gemini API key is missing. Please set GEMINI_API_KEY in Settings."))
    }

    // gemini-2.5-flash-image is the recommended model for image generation
    val model = "gemini-2.5-flash-image"
    val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"

    try {
      val requestBodyJson = JSONObject()
      val contentsArray = JSONArray()
      val contentObj = JSONObject()
      val partsArray = JSONArray()

      if (referenceImagePath != null) {
        val base64 = encodeImageToBase64(referenceImagePath)
        if (base64 != null) {
          partsArray.put(
            JSONObject().put(
              "inlineData",
              JSONObject().put("mimeType", "image/jpeg").put("data", base64)
            )
          )
        }
      }

      val finalPrompt = ImagePromptEnhancer.enhance(prompt, styleId, referenceImagePath != null)
      partsArray.put(JSONObject().put("text", finalPrompt))
      contentObj.put("role", "user")
      contentObj.put("parts", partsArray)
      contentsArray.put(contentObj)
      requestBodyJson.put("contents", contentsArray)

      val generationConfig = JSONObject()
        .put("responseModalities", JSONArray().put("TEXT").put("IMAGE"))
        .put("imageConfig", JSONObject().put("aspectRatio", aspectRatio))
      requestBodyJson.put("generationConfig", generationConfig)

      val request = Request.Builder()
        .url(url)
        .header("x-goog-api-key", apiKey)
        .post(requestBodyJson.toString().toRequestBody(jsonMediaType))
        .build()

      val response = imageClient.newCall(request).execute()
      val responseText = response.body?.string() ?: ""

      if (!response.isSuccessful) {
        return@withContext Result.failure(Exception(parseErrorMessage(response.code, responseText)))
      }

      val json = JSONObject(responseText)
      val candidates = json.optJSONArray("candidates")
      val parts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")

      var foundBase64 = ""
      var caption = ""

      if (parts != null) {
        for (i in 0 until parts.length()) {
          val part = parts.optJSONObject(i) ?: continue
          val inlineData = part.optJSONObject("inlineData")
          if (inlineData != null) {
            foundBase64 = inlineData.optString("data", "")
          }
          val text = part.optString("text", "")
          if (text.isNotEmpty()) {
            caption = text
          }
        }
      }

      if (foundBase64.isNotEmpty()) {
        Result.success(Pair(foundBase64, caption))
      } else {
        Result.failure(Exception("Image generation did not return image data: $caption"))
      }
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  private fun buildSystemPrompt(settings: UserSettings): String {
    val toneInstruction = when (settings.tone) {
      "Concise" -> "Keep answers brief, highly direct, and compact without filler."
      "Professional" -> "Maintain an authoritative, polished, and structured tone."
      "Sigma" -> "Sigma mode: calm, confident and direct. No filler, no flattery, no needless apologies. " +
        "Lead with the answer, then 2-4 sharp bullet points, then one clear next step. Stay respectful, never arrogant."
      "Playful" -> "Be enthusiastic, witty, friendly, and imaginative."
      "Custom" -> "Adapt to custom instructions if provided."
      else -> "Be warm, helpful, natural, and clear."
    }

    val userBio = if (settings.aboutYou.isNotBlank()) "User context: ${settings.aboutYou}." else ""
    val userNameLine = if (settings.userName.isNotBlank()) "The user's name is ${settings.userName}." else ""

    return """
      You are Rizvi@gpt, an original, elegant, and intelligent AI assistant.
      $userNameLine
      $userBio
      Language: always reply in the language the user writes in. If the user writes Bangla (বাংলা),
      reply in natural, fluent Bangla. If the user mixes Bangla and English, mirror that mix.
      Communication Style: $toneInstruction
      Guidelines:
      - Use clean Markdown with headers, bullet points, numbered lists, and bold text when helpful.
      - If explaining health or fitness, include a brief 'consult a professional' note.
      - For identification tasks (plants, objects, art), clearly state visual characteristics and remind user to verify.
      - Do not identify real individual faces from photos; focus on describing scenes, aesthetics, styling, or objects.
      - Keep responses snappy and mobile-friendly.
    """.trimIndent()
  }

  private fun encodeImageToBase64(path: String): String? {
    return try {
      val file = File(path)
      if (!file.exists()) return null
      val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
      BitmapFactory.decodeFile(file.absolutePath, boundsOptions)

      val maxDimension = 1600
      var sampleSize = 1
      while (boundsOptions.outWidth / sampleSize > maxDimension || boundsOptions.outHeight / sampleSize > maxDimension) {
        sampleSize *= 2
      }

      val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
      val bitmap = BitmapFactory.decodeFile(file.absolutePath, decodeOptions) ?: return null

      val outputStream = ByteArrayOutputStream()
      bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
      Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    } catch (_: Exception) {
      null
    }
  }

  private fun parseErrorMessage(code: Int, body: String): String {
    return try {
      val json = JSONObject(body)
      val err = json.optJSONObject("error")
      val msg = err?.optString("message") ?: "HTTP $code error"
      "API Error: $msg"
    } catch (_: Exception) {
      "HTTP $code: $body"
    }
  }
}
