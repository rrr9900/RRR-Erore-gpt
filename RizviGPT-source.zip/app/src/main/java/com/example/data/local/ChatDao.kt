package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
  @Query("SELECT * FROM chats ORDER BY isPinned DESC, updatedAt DESC")
  fun getAllChats(): Flow<List<ChatEntity>>

  @Query("SELECT * FROM chats WHERE id = :chatId LIMIT 1")
  fun getChatById(chatId: String): Flow<ChatEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertChat(chat: ChatEntity)

  @Update
  suspend fun updateChat(chat: ChatEntity)

  @Query("DELETE FROM chats WHERE id = :chatId")
  suspend fun deleteChatById(chatId: String)

  @Query("DELETE FROM chats")
  suspend fun deleteAllChats()

  @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp ASC")
  fun getMessagesForChat(chatId: String): Flow<List<MessageEntity>>

  @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp ASC")
  suspend fun getMessagesForChatSync(chatId: String): List<MessageEntity>

  @Query("SELECT id, chatId, role, content, imageUris, NULL AS generatedImageBase64, status, feedback, timestamp FROM messages ORDER BY timestamp ASC")
  suspend fun getAllMessagesForExport(): List<MessageEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMessage(message: MessageEntity)

  @Update
  suspend fun updateMessage(message: MessageEntity)

  @Query("DELETE FROM messages WHERE id = :messageId")
  suspend fun deleteMessageById(messageId: String)

  @Query("DELETE FROM messages WHERE chatId = :chatId")
  suspend fun deleteMessagesForChat(chatId: String)

  @Query("UPDATE messages SET feedback = :feedback WHERE id = :messageId")
  suspend fun updateMessageFeedback(messageId: String, feedback: Int)

  @Query("UPDATE messages SET content = :content, status = :status WHERE id = :messageId")
  suspend fun updateMessageContent(messageId: String, content: String, status: String)

  @Query("UPDATE chats SET title = :title, updatedAt = :updatedAt WHERE id = :chatId")
  suspend fun updateChatTitle(chatId: String, title: String, updatedAt: Long = System.currentTimeMillis())

  @Query("UPDATE chats SET isPinned = :isPinned WHERE id = :chatId")
  suspend fun updateChatPin(chatId: String, isPinned: Boolean)
}
