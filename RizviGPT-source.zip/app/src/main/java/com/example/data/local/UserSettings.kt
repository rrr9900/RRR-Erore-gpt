package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class UserSettings(
  val userName: String = "",
  val themeMode: String = "system", // "system", "light", "dark"
  val accentIndex: Int = 0,
  val fontSize: String = "medium", // "small", "medium", "large"
  val tone: String = "Friendly", // "Friendly", "Concise", "Professional", "Playful", "Sigma", "Custom"
  val aboutYou: String = "",
  val voicePersona: String = "Sol", // "Sol", "Ember", "Atlas", "Lyra", "Echo"
  val speechRate: Float = 1.0f,
  val language: String = "Auto",
  val responseStyle: String = "Instant", // "Instant", "Thoughtful"
  val hasCompletedOnboarding: Boolean = false,
  val apiKey: String = "" // Custom user-provided Gemini API Key
) {
  val fontScale: Float
    get() = when (fontSize) {
      "small" -> 0.9f
      "large" -> 1.15f
      else -> 1.0f
    }
}

class SettingsManager(context: Context) {
  private val prefs: SharedPreferences =
    context.getSharedPreferences("kora_user_settings", Context.MODE_PRIVATE)

  private val _settings = MutableStateFlow(loadSettings())
  val settings: StateFlow<UserSettings> = _settings.asStateFlow()

  private fun loadSettings(): UserSettings {
    return UserSettings(
      userName = prefs.getString("user_name", "") ?: "",
      themeMode = prefs.getString("theme_mode", "system") ?: "system",
      accentIndex = prefs.getInt("accent_index", 0),
      fontSize = prefs.getString("font_size", "medium") ?: "medium",
      tone = prefs.getString("tone", "Friendly") ?: "Friendly",
      aboutYou = prefs.getString("about_you", "") ?: "",
      voicePersona = prefs.getString("voice_persona", "Sol") ?: "Sol",
      speechRate = prefs.getFloat("speech_rate", 1.0f),
      language = prefs.getString("language", "Auto") ?: "Auto",
      responseStyle = prefs.getString("response_style", "Instant") ?: "Instant",
      hasCompletedOnboarding = prefs.getBoolean("has_completed_onboarding", false),
      apiKey = KeyCipher.decrypt(prefs.getString("custom_api_key", "") ?: "")
    )
  }

  fun updateSettings(newSettings: UserSettings) {
    prefs.edit()
      .putString("user_name", newSettings.userName)
      .putString("theme_mode", newSettings.themeMode)
      .putInt("accent_index", newSettings.accentIndex)
      .putString("font_size", newSettings.fontSize)
      .putString("tone", newSettings.tone)
      .putString("about_you", newSettings.aboutYou)
      .putString("voice_persona", newSettings.voicePersona)
      .putFloat("speech_rate", newSettings.speechRate)
      .putString("language", newSettings.language)
      .putString("response_style", newSettings.responseStyle)
      .putBoolean("has_completed_onboarding", newSettings.hasCompletedOnboarding)
      .putString("custom_api_key", KeyCipher.encrypt(newSettings.apiKey.trim()))
      .apply()
    _settings.value = newSettings
  }

  fun completeOnboarding() {
    val updated = _settings.value.copy(hasCompletedOnboarding = true)
    updateSettings(updated)
  }

  fun clearAllData() {
    prefs.edit().clear().apply()
    _settings.value = UserSettings()
  }
}
