package com.example.data.remote

/** One selectable look for the image generator. */
data class ImageStyle(
  val id: String,
  val label: String,
  val hint: String
)

/** Aspect ratios supported by the Gemini image model. */
data class ImageAspect(
  val id: String, // value sent to the API, e.g. "4:5"
  val label: String
)

val IMAGE_STYLES = listOf(
  ImageStyle("photoreal", "Realistic Photo", "Looks like a real camera photo"),
  ImageStyle("portrait", "Portrait", "Natural skin, studio or window light"),
  ImageStyle("product", "Product", "Clean commercial product shot"),
  ImageStyle("nature", "Nature", "Landscape and wildlife photography"),
  ImageStyle("cinematic", "Cinematic", "Movie-still lighting and colour"),
  ImageStyle("art", "Digital Art", "Stylised illustration, free creative look"),
  ImageStyle("free", "Free (no change)", "Use my prompt exactly as written")
)

val IMAGE_ASPECTS = listOf(
  ImageAspect("1:1", "Square 1:1"),
  ImageAspect("4:5", "Portrait 4:5"),
  ImageAspect("9:16", "Story 9:16"),
  ImageAspect("16:9", "Wide 16:9")
)

/**
 * Turns a short user idea into a detailed prompt (camera, lens, light, texture) so the model
 * produces much more realistic and professional pictures. The user's own words stay in the
 * prompt untouched.
 */
object ImagePromptEnhancer {

  fun enhance(userPrompt: String, styleId: String, hasReferenceImage: Boolean): String {
    val idea = userPrompt.trim()
    val reference = if (hasReferenceImage) {
      "Use the attached photo as the visual reference / base and keep the main subject recognisable. "
    } else {
      ""
    }

    val body = when (styleId) {
      "photoreal" ->
        "Ultra-realistic photograph of: $idea. " +
          "Shot on a full-frame mirrorless camera, 35mm lens, aperture f/2.0, natural soft light, " +
          "true-to-life colours, realistic textures and skin pores, natural depth of field, " +
          "subtle film grain, sharp focus on the subject. " +
          "Avoid: plastic or CGI look, distorted hands or fingers, warped faces, text, watermark, logos."

      "portrait" ->
        "Professional portrait photograph of: $idea. " +
          "85mm portrait lens, aperture f/1.8, soft window light with gentle rim light, " +
          "natural skin texture, catchlights in the eyes, creamy background blur, " +
          "realistic hair detail, balanced colour grade. " +
          "Avoid: over-smoothed skin, extra fingers, asymmetrical eyes, text, watermark."

      "product" ->
        "High-end commercial product photograph of: $idea. " +
          "Clean seamless backdrop, softbox studio lighting, crisp reflections and soft shadows, " +
          "macro-level material detail, centred premium composition. " +
          "Avoid: clutter, text, watermark, distorted shapes."

      "nature" ->
        "Award-winning nature photograph of: $idea. " +
          "Golden-hour natural light, rich but realistic colours, atmospheric depth with soft mist, " +
          "fine detail in leaves, water and fur, wide dynamic range, tripod-sharp. " +
          "Avoid: oversaturation, artificial glow, text, watermark."

      "cinematic" ->
        "Cinematic film still of: $idea. " +
          "Anamorphic lens, dramatic motivated lighting, shallow depth of field, " +
          "teal-and-orange colour grade, film grain, 2.39:1 movie mood. " +
          "Avoid: text, subtitles, watermark."

      "art" ->
        "Beautiful, highly detailed digital artwork of: $idea. " +
          "Harmonious colour palette, strong composition, polished professional finish."

      else -> idea
    }

    return reference + body
  }
}
