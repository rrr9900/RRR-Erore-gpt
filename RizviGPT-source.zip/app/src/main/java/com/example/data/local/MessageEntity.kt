package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(
  tableName = "messages",
  foreignKeys = [
    ForeignKey(
      entity = ChatEntity::class,
      parentColumns = ["id"],
      childColumns = ["chatId"],
      onDelete = ForeignKey.CASCADE
    )
  ],
  indices = [Index(value = ["chatId"])]
)
data class MessageEntity(
  @PrimaryKey
  val id: String = UUID.randomUUID().toString(),
  val chatId: String,
  val role: String, // "user" or "assistant"
  val content: String,
  val imageUris: String = "", // Comma-separated or JSON list of image URIs/paths
  val generatedImageBase64: String? = null,
  val status: String = "done", // "streaming", "done", "error"
  val feedback: Int = 0, // 0 = none, 1 = up, -1 = down
  val timestamp: Long = System.currentTimeMillis()
)
