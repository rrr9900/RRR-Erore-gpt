package com.example.data.local

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypts small secrets (the user's API key) with a key that lives in the Android Keystore,
 * so the secret is never stored as readable text in SharedPreferences.
 */
object KeyCipher {
  private const val ANDROID_KEYSTORE = "AndroidKeyStore"
  private const val KEY_ALIAS = "rizvigpt_api_key_v1"
  private const val TRANSFORMATION = "AES/GCM/NoPadding"
  const val PREFIX = "enc1:"

  private fun getOrCreateKey(): SecretKey {
    val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
    val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
    if (existing != null) return existing

    val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
    generator.init(
      KeyGenParameterSpec.Builder(
        KEY_ALIAS,
        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
      )
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setKeySize(256)
        .build()
    )
    return generator.generateKey()
  }

  /** Returns "enc1:<iv>:<cipher>" (Base64). Falls back to plain text only if the Keystore fails. */
  fun encrypt(plain: String): String {
    if (plain.isEmpty()) return ""
    return try {
      val cipher = Cipher.getInstance(TRANSFORMATION)
      cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
      val iv = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
      val data = Base64.encodeToString(cipher.doFinal(plain.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
      "$PREFIX$iv:$data"
    } catch (_: Exception) {
      plain
    }
  }

  /** Accepts both new encrypted values and legacy plain-text values saved by older versions. */
  fun decrypt(stored: String): String {
    if (stored.isEmpty()) return ""
    if (!stored.startsWith(PREFIX)) return stored // legacy plain value
    return try {
      val parts = stored.removePrefix(PREFIX).split(":")
      if (parts.size != 2) return ""
      val iv = Base64.decode(parts[0], Base64.NO_WRAP)
      val data = Base64.decode(parts[1], Base64.NO_WRAP)
      val cipher = Cipher.getInstance(TRANSFORMATION)
      cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
      String(cipher.doFinal(data), Charsets.UTF_8)
    } catch (_: Exception) {
      ""
    }
  }
}
