package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

data class VoicePersona(
  val id: String,
  val name: String,
  val vibe: String,
  val pitch: Float,
  val rateModifier: Float
)

val VOICE_PERSONAS = listOf(
  VoicePersona("Sol", "Sol", "Savvy and relaxed", 0.95f, 0.95f),
  VoicePersona("Ember", "Ember", "Warm and upbeat", 1.15f, 1.05f),
  VoicePersona("Atlas", "Atlas", "Calm and precise", 0.85f, 0.90f),
  VoicePersona("Lyra", "Lyra", "Bright and expressive", 1.25f, 1.10f),
  VoicePersona("Echo", "Echo", "Smooth and minimalist", 1.0f, 1.0f)
)

enum class OrbVisualState {
  IDLE,
  LISTENING,
  THINKING,
  SPEAKING
}

class VoiceManager(private val context: Context) : RecognitionListener, TextToSpeech.OnInitListener {

  private var speechRecognizer: SpeechRecognizer? = null
  private var textToSpeech: TextToSpeech? = null
  private var isTtsInitialized = false

  private val _isListening = MutableStateFlow(false)
  val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

  private val _isSpeaking = MutableStateFlow(false)
  val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

  private val _isThinking = MutableStateFlow(false)
  val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

  private val _recognizedText = MutableStateFlow("")
  val recognizedText: StateFlow<String> = _recognizedText.asStateFlow()

  private val _amplitude = MutableStateFlow(0f)
  val amplitude: StateFlow<Float> = _amplitude.asStateFlow()

  var onFinalSpeechResult: ((String) -> Unit)? = null
  var onSpeechPartialResult: ((String) -> Unit)? = null
  var onRecognitionError: ((Int) -> Unit)? = null

  init {
    textToSpeech = TextToSpeech(context.applicationContext, this)
    if (SpeechRecognizer.isRecognitionAvailable(context)) {
      speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
        setRecognitionListener(this@VoiceManager)
      }
    }
  }

  override fun onInit(status: Int) {
    if (status == TextToSpeech.SUCCESS) {
      isTtsInitialized = true
      textToSpeech?.language = Locale.getDefault()
      textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
          _isSpeaking.value = true
        }

        override fun onDone(utteranceId: String?) {
          _isSpeaking.value = false
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
          _isSpeaking.value = false
        }
      })
    }
  }

  fun startListening(languageCode: String = "Auto") {
    // Stop any active TTS if user starts speaking (barge-in support)
    stopSpeaking()

    if (speechRecognizer == null) {
      if (SpeechRecognizer.isRecognitionAvailable(context)) {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
          setRecognitionListener(this@VoiceManager)
        }
      }
    }

    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
      putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
      putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
      if (languageCode != "Auto") {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageCode)
      }
    }

    try {
      _isListening.value = true
      speechRecognizer?.startListening(intent)
    } catch (_: Exception) {
      _isListening.value = false
    }
  }

  fun stopListening() {
    _isListening.value = false
    _amplitude.value = 0f
    try {
      speechRecognizer?.stopListening()
    } catch (_: Exception) {}
  }

  fun setThinking(thinking: Boolean) {
    _isThinking.value = thinking
  }

  fun speak(text: String, personaName: String = "Sol", speechRate: Float = 1.0f) {
    if (!isTtsInitialized || textToSpeech == null) return

    val cleanText = text
      .replace(Regex("#+\\s*"), "") // remove markdown headings
      .replace(Regex("\\*\\*|\\*"), "") // remove asterisks
      .replace(Regex("`{1,3}[^`]*`{1,3}"), "") // remove code spans

    val persona = VOICE_PERSONAS.find { it.name.equals(personaName, ignoreCase = true) }
      ?: VOICE_PERSONAS[0]

    textToSpeech?.setPitch(persona.pitch)
    textToSpeech?.setSpeechRate(speechRate * persona.rateModifier)

    _isSpeaking.value = true
    val params = Bundle()
    params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "rizvi_voice_${System.currentTimeMillis()}")
    textToSpeech?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params, "rizvi_voice")
  }

  fun stopSpeaking() {
    textToSpeech?.stop()
    _isSpeaking.value = false
  }

  fun destroy() {
    stopSpeaking()
    stopListening()
    try {
      speechRecognizer?.destroy()
    } catch (_: Exception) {}
    speechRecognizer = null
    textToSpeech?.shutdown()
    textToSpeech = null
  }

  // RecognitionListener callbacks
  override fun onReadyForSpeech(params: Bundle?) {
    _isListening.value = true
  }

  override fun onBeginningOfSpeech() {
    _isListening.value = true
  }

  override fun onRmsChanged(rmsdB: Float) {
    // rmsdB is typically between -2 and 10
    val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
    _amplitude.value = normalized
  }

  override fun onBufferReceived(buffer: ByteArray?) {}

  override fun onEndOfSpeech() {
    _isListening.value = false
    _amplitude.value = 0f
  }

  override fun onError(error: Int) {
    _isListening.value = false
    _amplitude.value = 0f
    onRecognitionError?.invoke(error)
  }

  override fun onResults(results: Bundle?) {
    _isListening.value = false
    _amplitude.value = 0f
    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
    val text = matches?.firstOrNull() ?: ""
    if (text.isNotBlank()) {
      _recognizedText.value = text
      onFinalSpeechResult?.invoke(text)
    }
  }

  override fun onPartialResults(partialResults: Bundle?) {
    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
    val text = matches?.firstOrNull() ?: ""
    if (text.isNotBlank()) {
      _recognizedText.value = text
      onSpeechPartialResult?.invoke(text)
    }
  }

  override fun onEvent(eventType: Int, params: Bundle?) {}
}
