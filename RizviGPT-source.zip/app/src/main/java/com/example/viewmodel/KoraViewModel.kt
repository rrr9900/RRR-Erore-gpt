package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ChatEntity
import com.example.data.local.MessageEntity
import com.example.data.local.SettingsManager
import com.example.data.local.UserSettings
import com.example.data.remote.GeminiClient
import com.example.data.remote.IMAGE_ASPECTS
import com.example.data.remote.IMAGE_STYLES
import com.example.voice.OrbVisualState
import com.example.voice.VoiceManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class KoraViewModel(application: Application) : AndroidViewModel(application) {

  private val database = AppDatabase.getDatabase(application)
  private val chatDao = database.chatDao()
  private val settingsManager = SettingsManager(application)
  private val geminiClient = GeminiClient()
  val voiceManager = VoiceManager(application)

  val settings: StateFlow<UserSettings> = settingsManager.settings

  val chats: StateFlow<List<ChatEntity>> = chatDao.getAllChats()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _activeChatId = MutableStateFlow<String?>(null)
  val activeChatId: StateFlow<String?> = _activeChatId.asStateFlow()

  val messages: StateFlow<List<MessageEntity>> = _activeChatId.flatMapLatest { chatId ->
    if (chatId == null) flowOf(emptyList())
    else chatDao.getMessagesForChat(chatId)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _inputText = MutableStateFlow("")
  val inputText: StateFlow<String> = _inputText.asStateFlow()

  private val _attachedImages = MutableStateFlow<List<String>>(emptyList())
  val attachedImages: StateFlow<List<String>> = _attachedImages.asStateFlow()

  private val _isImageGenMode = MutableStateFlow(false)
  val isImageGenMode: StateFlow<Boolean> = _isImageGenMode.asStateFlow()

  private val _imageStyleId = MutableStateFlow(IMAGE_STYLES.first().id)
  val imageStyleId: StateFlow<String> = _imageStyleId.asStateFlow()

  private val _imageAspectId = MutableStateFlow(IMAGE_ASPECTS.first().id)
  val imageAspectId: StateFlow<String> = _imageAspectId.asStateFlow()

  // Text that was already in the input box when dictation started
  private var dictationPrefix = ""

  private val _isGenerating = MutableStateFlow(false)
  val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

  private var activeGenerationJob: Job? = null

  // Voice mode state
  private val _voiceSessionActive = MutableStateFlow(false)
  val voiceSessionActive: StateFlow<Boolean> = _voiceSessionActive.asStateFlow()

  private val _voiceLiveCaption = MutableStateFlow("")
  val voiceLiveCaption: StateFlow<String> = _voiceLiveCaption.asStateFlow()

  private val _voiceOrbVisualState = MutableStateFlow(OrbVisualState.IDLE)
  val voiceOrbVisualState: StateFlow<OrbVisualState> = _voiceOrbVisualState.asStateFlow()

  init {
    viewModelScope.launch {
      // Setup Voice recognition callbacks
      voiceManager.onSpeechPartialResult = { partial ->
        if (_voiceSessionActive.value) {
          _voiceLiveCaption.value = partial
        } else {
          // Dictation from the chat input bar: show words live in the text box
          _inputText.value = (dictationPrefix + " " + partial).trim()
        }
      }

      voiceManager.onFinalSpeechResult = { finalSpeech ->
        if (_voiceSessionActive.value) {
          _voiceLiveCaption.value = finalSpeech
          if (finalSpeech.isNotBlank()) handleVoiceInput(finalSpeech)
        } else {
          _inputText.value = (dictationPrefix + " " + finalSpeech).trim()
        }
      }

      voiceManager.onRecognitionError = { errorCode ->
        if (_voiceSessionActive.value) {
          val retryable = errorCode == android.speech.SpeechRecognizer.ERROR_NO_MATCH ||
            errorCode == android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT
          if (retryable) {
            viewModelScope.launch {
              kotlinx.coroutines.delay(500)
              if (_voiceSessionActive.value && !voiceManager.isSpeaking.value &&
                _voiceOrbVisualState.value == OrbVisualState.LISTENING
              ) {
                voiceManager.startListening(settings.value.language)
              }
            }
          } else if (_voiceOrbVisualState.value == OrbVisualState.LISTENING) {
            _voiceOrbVisualState.value = OrbVisualState.IDLE
            _voiceLiveCaption.value = "Microphone or network problem. Tap the mic to try again."
          }
        }
      }
    }
  }

  fun setInputText(text: String) {
    _inputText.value = text
  }

  fun addAttachedImage(path: String) {
    if (_attachedImages.value.size < 4 && !_attachedImages.value.contains(path)) {
      _attachedImages.value = _attachedImages.value + path
    }
  }

  fun removeAttachedImage(path: String) {
    _attachedImages.value = _attachedImages.value - path
  }

  fun clearAttachedImages() {
    _attachedImages.value = emptyList()
  }

  fun setImageGenMode(enabled: Boolean) {
    _isImageGenMode.value = enabled
  }

  fun setImageStyle(styleId: String) {
    _imageStyleId.value = styleId
  }

  fun setImageAspect(aspectId: String) {
    _imageAspectId.value = aspectId
  }

  /** Starts speech-to-text for the chat input box (not the full voice mode). */
  fun startDictation() {
    dictationPrefix = _inputText.value.trim()
    voiceManager.startListening(settings.value.language)
  }

  /** Retry listening inside voice mode (used by the mic button after an error). */
  fun retryVoiceListening() {
    if (_voiceSessionActive.value) {
      _voiceOrbVisualState.value = OrbVisualState.LISTENING
      _voiceLiveCaption.value = "Listening..."
      voiceManager.startListening(settings.value.language)
    }
  }

  fun selectChat(chatId: String) {
    _activeChatId.value = chatId
  }

  fun createNewChat(initialTitle: String = "New Chat"): String {
    val newId = UUID.randomUUID().toString()
    viewModelScope.launch {
      val chat = ChatEntity(id = newId, title = initialTitle)
      chatDao.insertChat(chat)
      _activeChatId.value = newId
    }
    return newId
  }

  fun deleteChat(chatId: String) {
    viewModelScope.launch {
      chatDao.deleteChatById(chatId)
      if (_activeChatId.value == chatId) {
        val remaining = chats.value.filter { it.id != chatId }
        _activeChatId.value = remaining.firstOrNull()?.id
      }
    }
  }

  fun clearAllChats() {
    viewModelScope.launch {
      chatDao.deleteAllChats()
      _activeChatId.value = null
    }
  }

  fun renameChat(chatId: String, newTitle: String) {
    viewModelScope.launch {
      chatDao.updateChatTitle(chatId, newTitle)
    }
  }

  fun togglePinChat(chatId: String) {
    viewModelScope.launch {
      val current = chats.value.find { it.id == chatId } ?: return@launch
      chatDao.updateChatPin(chatId, !current.isPinned)
    }
  }

  fun updateFeedback(messageId: String, feedback: Int) {
    viewModelScope.launch {
      chatDao.updateMessageFeedback(messageId, feedback)
    }
  }

  fun sendMessage(
    prompt: String = _inputText.value,
    images: List<String> = _attachedImages.value,
    insertUserMessage: Boolean = true
  ) {
    val cleanPrompt = prompt.trim()
    if (cleanPrompt.isEmpty() && images.isEmpty()) return

    // Ensure active chat exists
    var chatId = _activeChatId.value
    if (chatId == null) {
      chatId = createNewChat(generateChatTitle(cleanPrompt))
    }

    _inputText.value = ""
    _attachedImages.value = emptyList()

    viewModelScope.launch {
      // Insert user message
      val userMessage = MessageEntity(
        chatId = chatId,
        role = "user",
        content = cleanPrompt,
        imageUris = images.joinToString(","),
        status = "done"
      )
      if (insertUserMessage) {
        chatDao.insertMessage(userMessage)
      }

      // Create initial assistant message in streaming state
      val assistantMsgId = UUID.randomUUID().toString()
      val assistantMessage = MessageEntity(
        id = assistantMsgId,
        chatId = chatId,
        role = "assistant",
        content = "",
        status = "streaming"
      )
      chatDao.insertMessage(assistantMessage)

      _isGenerating.value = true

      activeGenerationJob = launch {
        if (_isImageGenMode.value) {
          // Image generation flow
          val refImage = images.firstOrNull()
          val result = geminiClient.generateImage(
            prompt = cleanPrompt,
            referenceImagePath = refImage,
            customApiKey = settings.value.apiKey,
            styleId = _imageStyleId.value,
            aspectRatio = _imageAspectId.value
          )
          result.fold(
            onSuccess = { (base64, caption) ->
              val desc = if (caption.isNotBlank()) caption else "Here is your generated image."
              // Big images must NOT live inside the database (it crashes the cursor window),
              // so write them to a file and keep only the path.
              val stored = saveGeneratedImage(assistantMsgId, base64)
              if (stored.isEmpty()) {
                chatDao.updateMessageContent(
                  assistantMsgId,
                  "Image generation failed: the picture could not be saved on this device (storage full?).",
                  "error"
                )
              } else {
                val updated = assistantMessage.copy(
                  content = desc,
                  generatedImageBase64 = stored,
                  status = "done"
                )
                chatDao.updateMessage(updated)
              }
            },
            onFailure = { err ->
              val errText = "Image generation failed: ${err.message}"
              chatDao.updateMessageContent(assistantMsgId, errText, "error")
            }
          )
          _isGenerating.value = false
        } else {
          // Conversational chat / streaming flow
          val history = chatDao.getMessagesForChatSync(chatId)
            .filter { it.status == "done" || it.id == userMessage.id }
            .takeLast(20)
            .map { it.role to it.content }

          val streamedText = StringBuilder()
          val result = geminiClient.streamChat(
            messages = history,
            imagePaths = images,
            settings = settings.value,
            onChunk = { chunk ->
              streamedText.append(chunk)
              viewModelScope.launch {
                chatDao.updateMessageContent(assistantMsgId, streamedText.toString(), "streaming")
              }
            }
          )

          result.fold(
            onSuccess = { finalText ->
              chatDao.updateMessageContent(assistantMsgId, finalText, "done")
              // Auto-generate title if default
              val currentChat = chats.value.find { it.id == chatId }
              if (currentChat?.title == "New Chat") {
                val newTitle = generateChatTitle(cleanPrompt)
                chatDao.updateChatTitle(chatId, newTitle)
              }
            },
            onFailure = { err ->
              val errText = "Unable to complete response: ${err.message}"
              chatDao.updateMessageContent(assistantMsgId, errText, "error")
            }
          )
          _isGenerating.value = false
        }
      }
    }
  }

  fun regenerateResponse(assistantMessageId: String) {
    val chatId = _activeChatId.value ?: return
    viewModelScope.launch {
      val msgs = chatDao.getMessagesForChatSync(chatId)
      val idx = msgs.indexOfFirst { it.id == assistantMessageId }
      if (idx > 0) {
        val prevUserMsg = msgs[idx - 1]
        chatDao.deleteMessageById(assistantMessageId)
        val images = if (prevUserMsg.imageUris.isBlank()) emptyList()
        else prevUserMsg.imageUris.split(",").map { it.trim() }

        // Send again
        sendMessage(prevUserMsg.content, images, insertUserMessage = false)
      }
    }
  }

  fun stopGenerating() {
    activeGenerationJob?.cancel()
    _isGenerating.value = false
    val chatId = _activeChatId.value ?: return
    viewModelScope.launch {
      val msgs = chatDao.getMessagesForChatSync(chatId)
      val streamingMsg = msgs.lastOrNull { it.status == "streaming" }
      if (streamingMsg != null) {
        val content = if (streamingMsg.content.isBlank()) "Generation stopped." else streamingMsg.content
        chatDao.updateMessageContent(streamingMsg.id, content, "done")
      }
    }
  }

  // Voice Mode flow
  fun openVoiceMode() {
    _voiceSessionActive.value = true
    _voiceLiveCaption.value = "Listening..."
    _voiceOrbVisualState.value = OrbVisualState.LISTENING
    voiceManager.startListening(settings.value.language)
  }

  fun closeVoiceMode() {
    _voiceSessionActive.value = false
    voiceManager.stopSpeaking()
    voiceManager.stopListening()
    _voiceOrbVisualState.value = OrbVisualState.IDLE
    _voiceLiveCaption.value = ""
  }

  private fun handleVoiceInput(speech: String) {
    val chatId = _activeChatId.value ?: createNewChat(generateChatTitle(speech))
    _voiceOrbVisualState.value = OrbVisualState.THINKING
    _voiceLiveCaption.value = "Thinking..."

    viewModelScope.launch {
      // Record user speech into chat
      val userMsg = MessageEntity(chatId = chatId, role = "user", content = speech)
      chatDao.insertMessage(userMsg)

      val history = chatDao.getMessagesForChatSync(chatId)
        .takeLast(10)
        .map { it.role to it.content }

      val result = geminiClient.streamChat(
        messages = history,
        settings = settings.value,
        onChunk = { /* voice uses full reply */ }
      )

      result.fold(
        onSuccess = { reply ->
          // Save assistant speech reply into chat
          val assistantMsg = MessageEntity(chatId = chatId, role = "assistant", content = reply)
          chatDao.insertMessage(assistantMsg)

          _voiceLiveCaption.value = reply
          _voiceOrbVisualState.value = OrbVisualState.SPEAKING
          voiceManager.speak(reply, settings.value.voicePersona, settings.value.speechRate)

          // Once finished speaking, resume listening
          launch {
            while (voiceManager.isSpeaking.value) {
              kotlinx.coroutines.delay(200)
            }
            if (_voiceSessionActive.value) {
              _voiceOrbVisualState.value = OrbVisualState.LISTENING
              _voiceLiveCaption.value = "Listening..."
              voiceManager.startListening(settings.value.language)
            }
          }
        },
        onFailure = { err ->
          _voiceLiveCaption.value = "Error: ${err.message}"
          _voiceOrbVisualState.value = OrbVisualState.IDLE
        }
      )
    }
  }

  private fun saveGeneratedImage(messageId: String, base64: String): String {
    return try {
      val bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
      val file = File(getApplication<Application>().filesDir, "gen_$messageId.img")
      file.writeBytes(bytes)
      "file:" + file.absolutePath
    } catch (_: Exception) {
      "" // image could not be stored
    }
  }

  /** Full export of every chat with its messages (images are not included). */
  suspend fun buildExportJson(): String {
    val allChats = chatDao.getAllChats().first()
    val allMessages = chatDao.getAllMessagesForExport()
    val root = JSONArray()
    allChats.forEach { chat ->
      val msgs = JSONArray()
      allMessages.filter { it.chatId == chat.id }.forEach { m ->
        msgs.put(
          JSONObject()
            .put("role", m.role)
            .put("content", m.content)
            .put("timestamp", m.timestamp)
        )
      }
      root.put(
        JSONObject()
          .put("id", chat.id)
          .put("title", chat.title)
          .put("createdAt", chat.createdAt)
          .put("messages", msgs)
      )
    }
    return root.toString(2)
  }

  fun updateSettings(newSettings: UserSettings) {
    settingsManager.updateSettings(newSettings)
  }

  fun completeOnboarding() {
    settingsManager.completeOnboarding()
  }

  fun resetAllData() {
    viewModelScope.launch {
      chatDao.deleteAllChats()
      getApplication<Application>().filesDir.listFiles()
        ?.filter { it.name.startsWith("gen_") }
        ?.forEach { it.delete() }
      settingsManager.clearAllData()
      _activeChatId.value = null
    }
  }

  private fun generateChatTitle(prompt: String): String {
    val cleaned = prompt.take(30).trim()
    return if (cleaned.isNotEmpty()) cleaned else "New Conversation"
  }

  override fun onCleared() {
    super.onCleared()
    voiceManager.destroy()
  }
}
