package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.ui.components.KoraOrb
import com.example.voice.OrbVisualState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.DrawerContent
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VoiceModeScreen
import com.example.ui.theme.AccentPresets
import com.example.ui.theme.KoraTheme
import com.example.viewmodel.KoraViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class AppScreen {
  SPLASH,
  ONBOARDING,
  CHAT,
  SETTINGS
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      val koraViewModel: KoraViewModel = viewModel()
      val settings by koraViewModel.settings.collectAsState()
      val voiceActive by koraViewModel.voiceSessionActive.collectAsState()

      val accentColor = AccentPresets.getOrElse(settings.accentIndex) { AccentPresets[0] }

      KoraTheme(
        themeMode = settings.themeMode,
        accentColor = accentColor,
        fontScaleMultiplier = settings.fontScale
      ) {
        KoraAppRoot(
          viewModel = koraViewModel
        )
      }
    }
  }
}

@Composable
fun KoraAppRoot(
  viewModel: KoraViewModel
) {
  val settings by viewModel.settings.collectAsState()
  val voiceActive by viewModel.voiceSessionActive.collectAsState()
  val coroutineScope = rememberCoroutineScope()
  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

  var currentScreen by remember { mutableStateOf(AppScreen.SPLASH) }

  // Splash Screen 1.2s Animation
  LaunchedEffect(Unit) {
    delay(1200)
    currentScreen = if (!settings.hasCompletedOnboarding) {
      AppScreen.ONBOARDING
    } else {
      AppScreen.CHAT
    }
  }

  // Handle system back navigation
  BackHandler(
    enabled = voiceActive || drawerState.isOpen || currentScreen == AppScreen.SETTINGS
  ) {
    when {
      voiceActive -> viewModel.closeVoiceMode()
      drawerState.isOpen -> coroutineScope.launch { drawerState.close() }
      currentScreen == AppScreen.SETTINGS -> currentScreen = AppScreen.CHAT
    }
  }

  Box(modifier = Modifier.fillMaxSize()) {
    when (currentScreen) {
      AppScreen.SPLASH -> {
        SplashScreen()
      }

      AppScreen.ONBOARDING -> {
        OnboardingScreen(
          onFinishOnboarding = {
            viewModel.completeOnboarding()
            currentScreen = AppScreen.CHAT
          }
        )
      }

      AppScreen.CHAT, AppScreen.SETTINGS -> {
        ModalNavigationDrawer(
          drawerState = drawerState,
          gesturesEnabled = currentScreen == AppScreen.CHAT && !voiceActive,
          drawerContent = {
            ModalDrawerSheet {
              DrawerContent(
                viewModel = viewModel,
                onOpenSettings = {
                  currentScreen = AppScreen.SETTINGS
                  coroutineScope.launch { drawerState.close() }
                },
                onCloseDrawer = {
                  coroutineScope.launch { drawerState.close() }
                }
              )
            }
          }
        ) {
          if (currentScreen == AppScreen.SETTINGS) {
            SettingsScreen(
              viewModel = viewModel,
              onBack = { currentScreen = AppScreen.CHAT }
            )
          } else {
            ChatScreen(
              viewModel = viewModel,
              onOpenDrawer = {
                coroutineScope.launch { drawerState.open() }
              },
              onOpenVoiceMode = {
                // Handled via voiceActive overlay
              }
            )
          }
        }
      }
    }

    // Voice mode full-screen overlay
    AnimatedVisibility(
      visible = voiceActive,
      enter = fadeIn(animationSpec = tween(300)),
      exit = fadeOut(animationSpec = tween(250))
    ) {
      VoiceModeScreen(
        viewModel = viewModel,
        onClose = { viewModel.closeVoiceMode() }
      )
    }
  }
}

@Composable
fun SplashScreen() {
  val pulseScale = remember { Animatable(0.85f) }

  LaunchedEffect(Unit) {
    pulseScale.animateTo(
      targetValue = 1.15f,
      animationSpec = tween(700, easing = FastOutSlowInEasing)
    )
    pulseScale.animateTo(
      targetValue = 1.0f,
      animationSpec = tween(500, easing = FastOutSlowInEasing)
    )
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F1115)),
    contentAlignment = Alignment.Center
  ) {
    com.example.ui.components.NatureBackground(modifier = Modifier.fillMaxSize())
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier.scale(pulseScale.value)
    ) {
      KoraOrb(
        state = OrbVisualState.IDLE,
        orbSize = 150.dp
      )
      Spacer(modifier = Modifier.height(24.dp))
      Text(
        text = "Rizvi@gpt",
        style = MaterialTheme.typography.displayMedium.copy(
          color = MaterialTheme.colorScheme.onBackground,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp
        )
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "Smart. Clear. Yours.",
        style = MaterialTheme.typography.bodyMedium.copy(
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      )
    }
  }
}
