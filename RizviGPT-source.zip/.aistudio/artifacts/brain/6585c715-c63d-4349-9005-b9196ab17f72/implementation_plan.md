# Kora - Native Android AI Assistant

A complete, polished, mobile-first Android AI assistant built natively with Jetpack Compose, Material 3, Room local persistence, and Gemini AI. Kora delivers conversational chat with Markdown streaming, multimodal image analysis and generation, an animated full-screen voice orb experience, and an onboarding journey.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural decisions were aligned based on your preferences:

- **Confirmed Decision 1 (Native Platform)**: Built as a 100% native Android application using Kotlin and Jetpack Compose, leveraging Android SpeechRecognizer, Text-to-Speech (TTS), and hardware-accelerated Canvas graphics.
- **Confirmed Decision 2 (Visual Aesthetic)**: Modern, airy light and dark Material 3 theme with soft pastel gradients, crisp rounded card contours (20-24dp), floating pill input (28dp), and an original abstract spark/orbit brand mark.
- **Confirmed Decision 3 (AI Capabilities Suite)**: Complete multimodal AI suite featuring fast Gemini Flash conversational chat, camera and gallery image analysis, photo transformation & art generation, and full-screen animated voice mode with persona presets.

---

## 1. Overview & Core Concept

- **What It Does**: Kora is an original, intelligent Android companion. Users can chat via text or voice, upload images for deep inspection (identification, reasoning, creative writing), generate visual concepts and stylized art variations, listen to spoken answers in customizable persona voices, and manage their conversation history.
- **Target Audience / Persona**: Everyday mobile users seeking creative inspiration, visual learning, text generation, and hands-free conversational assistance.
- **Key Value**: Delivers the fluid, responsive experience of flagship mobile AI assistants in a clean, private, on-device native Android architecture with no third-party branding or mock placeholders.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Onboarding Carousel (First Launch)**:
   - Soft pulsing spark/orbit logo splash.
   - 8 swipeable showcase cards on pastel gradient backdrops:
     1. *"Turn photos into ideas"* (minimalist logo concepts)
     2. *"Never stare at a blank page"* (creative brainstorming)
     3. *"Understand what you see"* (plant and object identification)
     4. *"Plan your next goal"* (structured fitness and study roadmaps)
     5. *"Talk it out loud"* (voice mode with animated breathing orb)
     6. *"Words in your voice"* (caption and tone crafting)
     7. *"Learn it your way"* (visual comic-style step explainers)
     8. *"Make ideas visible"* (photo to stylized art transformation)
   - Pager dots, Skip button, and Get Started CTA transitioning to the main chat.

2. **Main Chat & Suggestions**:
   - Clean top bar with navigation drawer trigger, current chat title, New Chat icon, and overflow actions (Rename, Export as Text, Delete Chat, Clear All).
   - Empty state: Personalized greeting (*"Hi {name}, what shall we create today?"*) and a horizontally scrollable strip of prompt suggestion chips.
   - Message feed:
     - User message: Right-aligned tinted container (`#E3E9FF` light / `#232A44` dark) with rounded 20dp corners and attached image thumbnails.
     - Assistant message: Left-aligned clean layout with rich Markdown rendering (bold, lists, tables, code blocks with quick-copy).
     - Streaming indicator: Subtle blinking caret and active "Stop generating" control.
     - Quick action row: Copy, Regenerate, Thumbs up/down, Read aloud, and Share.
   - Input pill bar: Elevated floating pill with `+` attachment sheet (Camera, Gallery, Create Image toggle), auto-expanding multiline text field, dictation microphone, and voice mode / send button.

3. **Full-Screen Voice Mode**:
   - Immersive dark/ambient backdrop featuring a 60fps Canvas gradient orb (blue → violet → white) that reacts dynamically:
     - *Idle*: Gentle harmonic breathing.
     - *Listening*: Organic waveform expansion reacting to microphone amplitude.
     - *Thinking*: Soft luminous swirl.
     - *Speaking*: Pulsing rhythmic aura synced with spoken audio.
   - Live transcription captions with toggle switch.
   - Bottom control panel: Mute mic, End session (`X`), and pull-up configuration sheet with Persona Carousel (*Sol*, *Ember*, *Atlas*, *Lyra*, *Echo*), Language selector, and Intelligence mode (Instant vs Thoughtful).

4. **Side Navigation Drawer**:
   - Search bar for filtering past conversations.
   - "New Chat" primary action button.
   - History list grouped chronologically: *Today*, *Yesterday*, *Previous 7 Days*, *Older*.
   - Quick actions: swipe to delete, long-press to rename or pin.
   - Bottom profile bar showing user avatar initial, name, and Settings shortcut.

5. **Settings & Customization**:
   - User Profile: Name and avatar color palette.
   - Appearance: Light, Dark, System; accent color presets (Indigo, Violet, Rose, Emerald, Amber); font size scale (Small, Medium, Large).
   - Voice Preferences: Default persona, speech rate slider, spoken language.
   - Personalization: "About You" and "Preferred Tone" (Friendly, Concise, Professional, Playful, Custom) injected into Gemini system instructions.
   - Data & Privacy: Clear history, Export chats (JSON), Reset all data.

### Visual Identity & Theme Tokens

- **Light Palette**:
  - Background: `#FFFFFF`
  - Surface: `#F6F8FC`
  - Primary: `#4F6BFF` (Deep Indigo-Blue)
  - Primary Container: `#E3E9FF` (User bubble)
  - Secondary: `#8B7BFF` (Soft Violet)
  - Accent: `#F4B6E0` (Pastel Blossom)
  - Text Primary: `#14161A`
  - Text Secondary: `#5B6270`
  - Divider: `#E6E9EF`
- **Dark Palette**:
  - Background: `#0F1115`
  - Surface: `#181B21`
  - Primary: `#8FA2FF`
  - User Bubble: `#232A44`
  - Text Primary: `#F2F4F8`
  - Text Secondary: `#A4ABB8`

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Native Room Persistence over Remote Database**:
  - *Chosen Approach*: Store chats, messages, and settings locally using Android Room SQLite database and DataStore preferences.
  - *Why*: Delivers instant cold launches, offline history access, zero authentication barriers, and complete user privacy without external account requirements.
- **Decision 2: Direct Gemini REST Client with Retrofit & OkHttp**:
  - *Chosen Approach*: Use Retrofit with streaming SSE support for `gemini-3.5-flash` (chat & vision) and `gemini-2.5-flash-image` (creative generation), secured via `BuildConfig.GEMINI_API_KEY`.
  - *Why*: Allows low-latency token streaming, full control over multimodal base64 image payloads, and reliable cancelable coroutine jobs.
- **Decision 3: Android SpeechRecognizer & TextToSpeech for Voice Mode**:
  - *Chosen Approach*: Leverage native Android `SpeechRecognizer` for real-time dictation and `TextToSpeech` with custom pitch/rate/locale presets for voice personas.
  - *Why*: Zero cloud latency for audio transport, reliable offline voice synthesis fallback, and direct hardware mic amplitude metering for orb animations.

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌────────────────────────────────────────────────────────────────────────┐
│                          Kora Android App                              │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │                    Jetpack Compose UI Layer                      │  │
│  │  ┌───────────────┐ ┌───────────────┐ ┌─────────────────────────┐ │  │
│  │  │ Onboarding    │ │ Chat Screen   │ │ Full-Screen Voice Mode  │ │  │
│  │  │ Carousel      │ │ & Drawer      │ │ & 60fps Canvas Orb      │ │  │
│  │  └───────┬───────┘ └───────┬───────┘ └────────────┬────────────┘ │  │
│  │          │                 │                      │              │  │
│  │  ┌───────┴─────────────────┴──────────────────────┴────────────┐ │  │
│  │  │               Settings & Customization Screen               │ │  │
│  │  └─────────────────────────┬───────────────────────────────────┘ │  │
│  └────────────────────────────┼─────────────────────────────────────┘  │
│                               │ UI State & User Events                 │
│  ┌────────────────────────────▼─────────────────────────────────────┐  │
│  │                         KoraViewModel                            │  │
│  │   • ChatState (active chat, messages, streaming buffer)          │  │
│  │   • VoiceState (listening, thinking, speaking, amplitude)        │  │
│  │   • SettingsState (theme, persona, tone, user profile)           │  │
│  └──────────────────────┬───────────────────────────┬───────────────┘  │
│                         │                           │                  │
│       ┌─────────────────▼─────────┐       ┌─────────▼───────────────┐  │
│       │      ChatRepository       │       │       GeminiService     │  │
│       │  • Room DAO persistence   │       │  • Retrofit / OkHttp    │  │
│       │  • Preferences DataStore  │       │  • Streaming SSE parser │  │
│       └─────────────┬─────────────┘       │  • Multimodal Vision    │  │
│                     │                     │  • Image Generation     │  │
│       ┌─────────────▼─────────────┐       └─────────┬───────────────┘  │
│       │    Room SQLite Database   │                 │                  │
│       │    (Chats & Messages)     │                 │ HTTPS REST       │
│       └───────────────────────────┘                 ▼                  │
│                                            Google Gemini API           │
└────────────────────────────────────────────────────────────────────────┘
```

### Data Model Entities

- **`ChatEntity`**:
  - `id: String` (UUID primary key)
  - `title: String`
  - `isPinned: Boolean`
  - `createdAt: Long`
  - `updatedAt: Long`

- **`MessageEntity`**:
  - `id: String` (UUID primary key)
  - `chatId: String` (Foreign key to `ChatEntity`)
  - `role: String` ("user" | "assistant")
  - `content: String`
  - `imageUris: String` (JSON array of attached image paths)
  - `generatedImageBase64: String?` (Optional generated image payload)
  - `status: String` ("streaming" | "done" | "error")
  - `feedback: Int` (0 = none, 1 = up, -1 = down)
  - `timestamp: Long`

- **`UserSettings`**:
  - `userName: String`
  - `themeMode: String` ("system" | "light" | "dark")
  - `accentColorIndex: Int`
  - `fontSize: String` ("small" | "medium" | "large")
  - `tone: String` ("Friendly" | "Concise" | "Professional" | "Playful" | "Custom")
  - `aboutYou: String`
  - `voicePersona: String` ("Sol" | "Ember" | "Atlas" | "Lyra" | "Echo")
  - `speechRate: Float`
  - `language: String`
  - `hasCompletedOnboarding: Boolean`

### Interactive Component & State Mapping

1. **Prompt Suggestion Chips**: Clicking any suggestion populates the input field and triggers auto-focus or image picker sheet as required.
2. **Streaming Parser**: Coroutine channel reads SSE tokens line-by-line from `streamGenerateContent`, updating UI StateFlow with minimal recomposition lag and caret animation.
3. **Voice Barge-In**: User speaking during assistant playback cancels TTS immediately and re-engages speech recognition.
4. **Adaptive Custom Launcher Icon**: High-contrast abstract spark/orbit icon configured in adaptive mipmaps according to Android specifications.
