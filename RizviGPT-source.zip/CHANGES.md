# Rizvi@gpt — what changed (v1.1)

## Name
- App name, splash, chat hint, "thinking" text, share text and the AI system prompt are now **Rizvi@gpt**.
- `applicationId` (com.aistudio.kora.aiasst) is intentionally unchanged so AI Studio signing keeps working.

## Bugs fixed
1. Back button now exits the app from the chat screen (it was always swallowed).
2. Microphone permission is asked only when you tap a mic button (not at startup).
3. Dictation (mic in the text box) now really types the words into the box.
4. Voice mode restarts listening after "no speech"/timeout instead of hanging; mute/unmute restores the orb.
5. Regenerate no longer duplicates your question.
6. Empty AI answers show a real error (with block reason) instead of the fake "I understand!" reply.
7. API key is stored encrypted (Android Keystore) and sent in a header, not in the URL.
8. Missing/unavailable models (404) now fall back to the next model.
9. Generated pictures are saved as files (big images inside the database could crash the chat list).
10. "Export all chats" now exports the real messages, saved through a file picker (no size crash).
11. Default name "Alex" removed. Backup of local data disabled (allowBackup=false).

## New
- Image mode: styles (Realistic Photo, Portrait, Product, Nature, Cinematic, Digital Art, Free),
  sizes (1:1, 4:5, 9:16, 16:9), automatic "photographer" prompt enhancer, Save-to-gallery button,
  correct aspect ratio display.
- Tone "Sigma" (calm, direct, no filler). The AI answers in the language you write (Bangla supported).
- Nature scene behind the chat and splash: time-of-day sky, mist, swaying hills, pollen/petals by day,
  fireflies at night. Follows light/dark theme, stays still if phone animations are off.
- Nature accent colours (Forest, Lagoon, Sky, Blossom, Sunrise) and a green orb.

## Not done
- Bangla UI translation, release (minified) build, live streaming voice.
